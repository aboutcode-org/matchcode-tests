int list_remove_item_at_pos(node **head, int pos)
 {    
//     if (head[pos] == NULL){
//         return EXIT_FAILURE;
//     }
//     head[pos] = NULL;
    return EXIT_SUCCESS;
}