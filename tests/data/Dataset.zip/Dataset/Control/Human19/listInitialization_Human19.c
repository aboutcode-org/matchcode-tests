int list_init(node **head)
{
    *head = malloc(sizeof(node));
    return EXIT_SUCCESS;
}