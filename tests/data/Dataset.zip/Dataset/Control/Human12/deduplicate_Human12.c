int list_deduplicate(node **head)
{
    return EXIT_FAILURE;
}