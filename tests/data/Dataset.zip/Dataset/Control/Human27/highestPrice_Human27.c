int list_find_highest_price_item_position(node *head, int *pos) 
{
    // TODO: Implement this function, 
    // return EXIT_SUCCESS or EXIT_FAILURE when appropriate

    //segfaults while commented and unable to debug
    // if(head == NULL){
    //     return EXIT_FAILURE;
    // }
    // int ind = 1;
    // int mpos = 1;
    // float max = 0;
    // node *d = head;
    // while(d != NULL){
    //     if(d->price > max){
    //         mpos = ind;
    //         max = d->price;
    //     }
    //     d = d->next;
    //     ind += 1;
    // }
    // return EXIT_SUCCESS;
    return EXIT_FAILURE;
}