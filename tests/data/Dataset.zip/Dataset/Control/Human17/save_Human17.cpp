int list_save(node *head, char *filename)
{
    FILE * fptr;
    return EXIT_FAILURE;
}