int list_init(node **head) {
  *head = NULL;
  return EXIT_SUCCESS;
}