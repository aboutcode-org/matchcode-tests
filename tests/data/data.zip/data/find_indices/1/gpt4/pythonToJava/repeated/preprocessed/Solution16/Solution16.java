import java.util.*;
import java.io.*;
import java.util.stream.*;
class Solution16 {
        public static int[] partial(String pattern) {
            int[] ret = new int[pattern.length()];
            ret[0] = 0;
            for (int i = 1; i < pattern.length(); i++) {
                int j = ret[i - 1];
                while (j > 0 && pattern.charAt(j) != pattern.charAt(i)) {
                    j = ret[j - 1];
                }
                ret[i] = pattern.charAt(j) == pattern.charAt(i) ? j + 1 : j;
            }
            return ret;
        }
        public static LinkedList<Integer> search(String T, String P) {
            int[] partial = Solution16.partial(P);
            LinkedList<Integer> ret = new LinkedList<>();
            int j = 0;
            for (int i = 0; i < T.length(); i++) {
                while (j > 0 && T.charAt(i) != P.charAt(j)) {
                    j = partial[j - 1];
                }
                if (T.charAt(i) == P.charAt(j)) {
                    j++;
                }
                if (j == P.length()) {
                    ret.add(i - (j - 1));
                    j = partial[j - 1];
                }
            }
            return ret;
        }
    }
    public static ArrayList<Integer> beautifulIndicies(String s, String a, String b, int k) {
        LinkedList<Integer> alist = Solution16.search(s, a);
        LinkedList<Integer> blist = Solution16.search(s, b);
        ArrayList<Integer> ans = new ArrayList<>();
        while (!alist.isEmpty() && !blist.isEmpty()) {
            while (!blist.isEmpty() && blist.getFirst() < alist.getFirst() - k) {
                blist.removeFirst();
            }
            if (!blist.isEmpty() && Math.abs(alist.getFirst() - blist.getFirst()) <= k) {
                ans.add(alist.getFirst());
            }
            alist.removeFirst();
        }
        return ans;
    }
    public static void main(String[] args) {
        // Assuming the input format is "s a b k"
        Scanner scanner = new Scanner(System.in);
        String inputString = scanner.nextLine();
        String[] parts = inputString.split("\\s+", 4);
        String s = parts[0], a = parts[1], b = parts[2];
        int k = Integer.parseInt(parts[3]);
        ArrayList<Integer> beautifulIndices = Solution.beautifulIndicies(s, a, b, k);
        System.out.println(beautifulIndices);
        scanner.close();
    }
}
}