import java.util.*;
import java.io.*;
import java.util.stream.*;
class KMP {
    // Calculate partial match table
    public int[] partial(String pattern) {  
        int[] ret = new int[pattern.length()];
        ret[0] = 0;
        for (int i = 1; i < pattern.length(); i++){
            int j = ret[i - 1];
            while (j > 0 && pattern.charAt(j) != pattern.charAt(i)) 
                j = ret[j - 1];
            ret[i] = (pattern.charAt(j) == pattern.charAt(i)) ? j + 1 : j;
        }
        return ret;
    }
    // KMP search main algorithm, return all the matching position of pattern string P in T
    public Deque<Integer> search(String T, String P) {
        int[] partial = this.partial(P);
        Deque<Integer> ret = new ArrayDeque<>();
        int j = 0;
        for (int i = 0; i < T.length(); i++){
            while (j > 0 && T.charAt(i) != P.charAt(j))
                j = partial[j - 1];
            if (T.charAt(i) == P.charAt(j)) j++;
            if (j == P.length()) {
                ret.add(i - (j - 1));
                j = partial[j - 1];
            }
        }
        return ret;
    }
}