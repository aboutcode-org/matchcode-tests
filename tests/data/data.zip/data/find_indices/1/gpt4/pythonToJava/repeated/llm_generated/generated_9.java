In Java, the converted code may look like this:

```Java
import java.util.*;
import java.util.stream.Collectors;

class KMP {
    static List<Integer> partial(String pattern) {
        List<Integer> ret = new ArrayList<>();
        ret.add(0);

        for (int i = 1; i < pattern.length(); i++) {
            int j = ret.get(i - 1);
            while (j > 0 && pattern.charAt(j) != pattern.charAt(i))
                j = ret.get(j - 1);
            ret.add(pattern.charAt(j) == pattern.charAt(i) ? j + 1 : j);
        }
        return ret;
    }

    static Deque<Integer> search(String T, String P) {
        List<Integer> partial = KMP.partial(P);
        Deque<Integer> ret = new ArrayDeque<>();
        int j = 0;

        for (int i = 0; i < T.length(); i++) {
            while (j > 0 && T.charAt(i) != P.charAt(j))
                j = partial.get(j - 1);
            if (T.charAt(i) == P.charAt(j)) j++;
            if (j == P.length()) {
                ret.add(i - (j - 1));
                j = partial.get(j - 1);
            }
        }
        return ret;
    }
}

class Solution {
    List<Integer> beautifulIndices(String s, String a, String b, int k) {
        Deque<Integer> queue1 = KMP.search(s, a);
        Deque<Integer> queue2 = KMP.search(s, b);
        List<Integer> ans = new ArrayList<>();

        while (!queue1.isEmpty() && !queue2.isEmpty()) {
            while (!queue2.isEmpty() && queue2.peekFirst() < queue1.peekFirst() - k)
                queue2.removeFirst();

            if (!queue2.isEmpty() && Math.abs(queue1.peekFirst() - queue2.peekFirst()) <= k)
                ans.add(queue1.peekFirst());

            queue1.removeFirst();
        }
        return ans;
    }
}

public class Main {
    public static void main(String[] args) {
        // Assuming the input format is "s a b k"
        Scanner scanner = new Scanner(System.in);
        String inputString = scanner.nextLine();
        String[] parts = inputString.split(" ");  // Split into 4 parts: s, a, b, and k
        String s = parts[0],
               a = parts[1],
               b = parts[2];
        int k = Integer.parseInt(parts[3]);

        Solution solution = new Solution();
        List<Integer> beautifulIndices = solution.beautifulIndices(s, a, b, k);
        System.out.println(beautifulIndices.stream().map(String::valueOf).collect(Collectors.joining(", ")));
    }
}
```

This is an equivalent Java code for the original Python code that uses KMP algorithm to find all pattern matching positions and then finds 'beauty' indices. 

Remember that in the Java version we have to deal with index-based access versus Python's direct iterable access, hence the difference in syntax, but semantic functionality is preserved. Also, Java's verbosity requires explicit type declarations.