Below is a direct translation of the provided Python code to Java:

```java
import java.util.*;

public class Solution {
    private static class KMP {
        public static int[] partial(String pattern) {
            int[] ret = new int[pattern.length()];
            ret[0] = 0;
            
            for (int i = 1; i < pattern.length(); i++) {
                int j = ret[i - 1];
                while (j > 0 && pattern.charAt(j) != pattern.charAt(i)) {
                    j = ret[j - 1];
                }
                ret[i] = pattern.charAt(j) == pattern.charAt(i) ? j + 1 : j;
            }

            return ret;
        }

        public static LinkedList<Integer> search(String T, String P) {
            int[] partial = KMP.partial(P);
            LinkedList<Integer> ret = new LinkedList<>();
            int j = 0;

            for (int i = 0; i < T.length(); i++) {
                while (j > 0 && T.charAt(i) != P.charAt(j)) {
                    j = partial[j - 1];
                }
                if (T.charAt(i) == P.charAt(j)) {
                    j++;
                }
                if (j == P.length()) {
                    ret.add(i - (j - 1));
                    j = partial[j - 1];
                }
            }

            return ret;
        }
    }

    public static ArrayList<Integer> beautifulIndicies(String s, String a, String b, int k) {
        LinkedList<Integer> alist = KMP.search(s, a);
        LinkedList<Integer> blist = KMP.search(s, b);
        ArrayList<Integer> ans = new ArrayList<>();

        while (!alist.isEmpty() && !blist.isEmpty()) {
            while (!blist.isEmpty() && blist.getFirst() < alist.getFirst() - k) {
                blist.removeFirst();
            }

            if (!blist.isEmpty() && Math.abs(alist.getFirst() - blist.getFirst()) <= k) {
                ans.add(alist.getFirst());
            }

            alist.removeFirst();
        }

        return ans;
    }
    
    public static void main(String[] args) {
        // Assuming the input format is "s a b k"
        Scanner scanner = new Scanner(System.in);
        String inputString = scanner.nextLine();
        String[] parts = inputString.split("\\s+", 4);
        String s = parts[0], a = parts[1], b = parts[2];
        int k = Integer.parseInt(parts[3]);

        ArrayList<Integer> beautifulIndices = Solution.beautifulIndicies(s, a, b, k);
        System.out.println(beautifulIndices);

        scanner.close();
    }
}
```

Note:
1. The `KMP` class in Python is translated to a static inner class in Java, since it doesn't need to maintain any state.
2. For `KMP.partial`, we need to initialize an array with the size equals to the length of the pattern in Java, as Java arrays are not as flexible as Python lists.
3. Deque operations in Python are replaced with LinkedList methods in Java.
4. For the main method, we use a Scanner to read the input line, and use `split` to divide the string into parts. After that, the process is similar to the Python version, converting the last part to an integer and calling the `beautifulIndicies` (typo in the original preserved on purpose) method.