import java.util.*;
import java.io.*;
import java.util.stream.*;
class Solution {
    public List<Integer> beautifulIndices(String s, String a, String b, int k) {
        Queue<Integer> aIndices = new LinkedList<>(KMP.search(s.toCharArray(), a.toCharArray()));
        Queue<Integer> bIndices = new LinkedList<>(KMP.search(s.toCharArray(), b.toCharArray()));
        List<Integer> ans = new ArrayList<>();
        while (!aIndices.isEmpty() && !bIndices.isEmpty()) {
            while (!bIndices.isEmpty() && bIndices.peek() < aIndices.peek() - k) {
                bIndices.poll();
            }
            if (!bIndices.isEmpty() && Math.abs(aIndices.peek() - bIndices.peek()) <= k) {
                ans.add(aIndices.peek());
            }
            aIndices.poll();
        }
        return ans;
    }
}