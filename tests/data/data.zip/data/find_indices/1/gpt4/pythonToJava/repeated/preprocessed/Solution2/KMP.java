import java.util.*;
import java.io.*;
import java.util.stream.*;
class KMP {
    static int[] getLPSArray(String str) {
        int[] lps = new int[str.length()];
        int len = 0;
        lps[0] = 0;
        int i = 1;
        while (i < str.length()) {
            if (str.charAt(i) == str.charAt(len)) {
                len++;
                lps[i] = len;
                i++;
            } else {
                if (len != 0) {
                    len = lps[len - 1];
                } else {
                    lps[i] = len;
                    i++;
                }
            }
        }
        return lps;
    }
    static Deque<Integer> KMPSearch(String txt, String pat) {
        int[] lps = getLPSArray(pat);
        Deque<Integer> result = new ArrayDeque<>();
        int i = 0;
        int j = 0;
        while (i < txt.length()) {
            if (pat.charAt(j) == txt.charAt(i)) {
                i++;
                j++;
            }
            if (j == pat.length()) {
                result.add(i - j);
                if (j != 0) j = lps[j - 1];
            } else if (i < txt.length() && pat.charAt(j) != txt.charAt(i)) {
                if (j != 0) j = lps[j - 1];
                else i++;
            }
        }
        return result;
    }
}