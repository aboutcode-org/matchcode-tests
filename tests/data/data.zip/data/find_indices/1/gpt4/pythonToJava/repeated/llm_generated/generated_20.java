Here is the Java code:

```java
import java.util.*;

// KMP
class KMP {
    public static int[] partial(String pattern) {
        int[] ret = new int[pattern.length()];
        ret[0] = 0;

        for (int i = 1; i < pattern.length(); i++) {
            int j = ret[i - 1];
            while (j > 0 && pattern.charAt(j) != pattern.charAt(i)) {
                j = ret[j - 1];
            }
            ret[i] = pattern.charAt(j) == pattern.charAt(i) ? j + 1 : j;
        }

        return ret;
    }

    public static List<Integer> search(String T, String P) {
        int[] partial = KMP.partial(P);
        List<Integer> ret = new ArrayList<>();
        int j = 0;

        for (int i = 0; i < T.length(); i++) {
            while (j > 0 && T.charAt(i) != P.charAt(j)) {
                j = partial[j - 1];
            }

            if (T.charAt(i) == P.charAt(j)) {
                j++;
            }
            if (j == P.length()) {
                ret.add(i - (j - 1));
                j = partial[j - 1];
            }
        }

        return ret;
    }
}

// Main
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String[] input = sc.nextLine().split(" ");
        String s = input[0];
        String a = input[1];
        String b = input[2];
        int k = Integer.parseInt(input[3]);

        List<Integer> indicesA = KMP.search(s, a);
        List<Integer> indicesB = KMP.search(s, b);
        List<Integer> beautifulIndices = new ArrayList<>();

        while (!indicesA.isEmpty() && !indicesB.isEmpty()) {
            while (!indicesB.isEmpty() && indicesB.get(0) < indicesA.get(0) - k) {
                indicesB.remove(0);
            }

            if (!indicesB.isEmpty() && Math.abs(indicesA.get(0) - indicesB.get(0)) <= k) {
                beautifulIndices.add(indicesA.get(0));
            }

            indicesA.remove(0);
        }

        System.out.println(beautifulIndices);
    }
}
```

This code first defines a Java version of the KMP class with two methods: `partial` and `search`.

In the main function, it obtains the user's input and performs a KMP search on the strings 'a' and 'b' and then puts computational results into the `beautifulIndices` ArrayList.

Finally, it uses the system output stream to print out all the beautiful indices.