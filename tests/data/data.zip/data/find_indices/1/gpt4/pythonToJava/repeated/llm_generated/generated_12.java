Below is the Java equivalent of the Python code, assuming that the main method accepts command line arguments:

```java
import java.util.*;

class KMP {
    public static int[] partial(String pattern) {
        int[] ret = new int[pattern.length()];
        ret[0] = 0;
        for (int i = 1; i < pattern.length(); i++) {
            int j = ret[i - 1];
            while (j > 0 && pattern.charAt(j) != pattern.charAt(i)) {
                j = ret[j - 1];
            }
            ret[i] = (pattern.charAt(j) == pattern.charAt(i)) ? (j + 1) : j;
        }
        return ret;
    }
    
    public static List<Integer> search(String T, String P) {
        int[] partial = KMP.partial(P);
        List<Integer> ret = new ArrayList<>();
        int j = 0;
        for (int i = 0; i < T.length(); i++) {
            while (j > 0 && T.charAt(i) != P.charAt(j)) {
                j = partial[j - 1];
            }
            if (T.charAt(i) == P.charAt(j)) {
                j += 1;
            }
            if (j == P.length()) {
                ret.add(i - (j - 1));
                j = partial[j - 1];
            }
        }
        return ret;
    }
}

public class Solution {
    public List<Integer> beautifulIndices(String s, String a, String b, int k) {
        List<Integer> aIndices = KMP.search(s, a);
        List<Integer> bIndices = KMP.search(s, b);
        List<Integer> ans = new ArrayList<>();

        while (!aIndices.isEmpty() && !bIndices.isEmpty()) {
            while (!bIndices.isEmpty() && bIndices.get(0) < aIndices.get(0) - k) {
                bIndices.remove(0);
            }
            if (!bIndices.isEmpty() && Math.abs(aIndices.get(0) - bIndices.get(0)) <= k) {
                ans.add(aIndices.get(0));
            }
            aIndices.remove(0);
        }
        return ans;
    }    

    public static void main(String[] args) {
        if (args.length < 4) {
            System.out.println("Please provide 4 arguments");
            return;
        }
        String s = args[0];
        String a = args[1];
        String b = args[2];
        int k = Integer.parseInt(args[3]);

        Solution solution = new Solution();
        List<Integer> beautifulIndices = solution.beautifulIndices(s, a, b, k);
        System.out.println(beautifulIndices);
    }
}
```

The main differences are in the syntax between both languages, but the logic remains the same. The command line arguments are accessed by `args` array in main method instead of doing an `input()` as in Python. Java has no intrinsic deque class, so `ArrayList` class is used and elements are removed by using `remove` function. Also, Java uses `charAt` method to access characters of a string. Calculation of the partial match table and the search algorithm of KMP are implemented in the same way.