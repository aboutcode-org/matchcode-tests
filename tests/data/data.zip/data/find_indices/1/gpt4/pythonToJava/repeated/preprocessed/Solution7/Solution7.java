import java.util.*;
import java.io.*;
import java.util.stream.*;
public class Solution7 {
    public static List<Integer> beautifulIndices(String s, String a, String b, int k) {
        LinkedList<Integer> patternAIndices = KMP.search(s, a);
        LinkedList<Integer> patternBIndices = KMP.search(s, b);
        ArrayList<Integer> beautifulIndices = new ArrayList<>();
        while (!patternAIndices.isEmpty() && !patternBIndices.isEmpty()) {
            while (!patternBIndices.isEmpty() && patternBIndices.getFirst() < patternAIndices.getFirst() - k) {
                patternBIndices.removeFirst();
            }
            if (!patternBIndices.isEmpty() && Math.abs(patternAIndices.getFirst() - patternBIndices.getFirst()) <= k) {
                beautifulIndices.add(patternAIndices.getFirst());
            }
            patternAIndices.removeFirst();
        }
        return beautifulIndices;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        String a = sc.nextLine();
        String b = sc.nextLine();
        int k = sc.nextInt();
        List<Integer> beautifulIndices = beautifulIndices(s, a, b, k);
        for (Integer index : beautifulIndices) {
            System.out.println(index);
        }
    }
}