import java.util.*;
import java.io.*;
import java.util.stream.*;
class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String s = scanner.nextLine();  // Assuming the input string is in the same order: "s a b k"
        String a = scanner.nextLine();
        String b = scanner.nextLine();
        int k = scanner.nextInt();
        Solution solution = new Solution();
        List<Integer> beautifulIndices = solution.beautifulIndices(s, a, b, k);
        System.out.println(beautifulIndices);
    }
}