import java.util.*;
import java.io.*;
import java.util.stream.*;
public class Solution11 {
    public ArrayList<Integer> beautifulIndices(String s, String a, String b, int k) {
        KMP kmp = new KMP();
        LinkedList<Integer> aIndices = kmp.search(s, a);
        LinkedList<Integer> bIndices = kmp.search(s, b);
        ArrayList<Integer> ans = new ArrayList<>();
        while (!aIndices.isEmpty() && !bIndices.isEmpty()) {
            while (!bIndices.isEmpty() && bIndices.peek() < aIndices.peek() - k) {
                bIndices.poll();
            }
            if (!bIndices.isEmpty() && Math.abs(aIndices.peek() - bIndices.peek()) <= k) {
                ans.add(aIndices.peek());
            }
            aIndices.poll();
        }
        return ans;
    }
    public static void main(String[] args) {
        // Expecting the user input to be: s a b k
        Scanner input = new Scanner(System.in);
        String s = input.next();
        String a = input.next();
        String b = input.next();
        int k = input.nextInt();
        Solution11 solution = new Solution11();
        ArrayList<Integer> beautifulIndices = solution.beautifulIndices(s, a, b, k);
        System.out.println(beautifulIndices);
    }
}