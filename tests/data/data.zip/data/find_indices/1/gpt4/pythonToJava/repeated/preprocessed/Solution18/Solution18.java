import java.util.*;
import java.io.*;
import java.util.stream.*;
class Solution18 {
    static int[] calculatePartialTable(String pattern) {
        int[] partialTable = new int[pattern.length()];
        for (int i = 1; i < pattern.length(); i++) {
            int j = partialTable[i - 1];
            while (j > 0 && pattern.charAt(j) != pattern.charAt(i)) {
                j = partialTable[j - 1];
            }
            partialTable[i] = pattern.charAt(j) == pattern.charAt(i) ? j+1 : j;
        }
        return partialTable;
    }
    static List<Integer> search(String target, String pattern) {
        int[] partialTable = calculatePartialTable(pattern);
        List<Integer> matches = new ArrayList<>();
        int j = 0;
        for (int i = 0; i < target.length(); i++) {
            while (j > 0 && target.charAt(i) != pattern.charAt(j)) {
                j = partialTable[j - 1];
            }
            if (target.charAt(i) == pattern.charAt(j)) {
                j++;
            }
            if (j == pattern.length()) {
                matches.add(i - j + 1);
                j = partialTable[j - 1];
            }
        }
        return matches;
    }
}