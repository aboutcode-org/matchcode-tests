import java.util.*;
import java.io.*;
import java.util.stream.*;
class Solution {
    public List<Integer> beautifulIndices(String s, String a, String b, int k) {
        List<Integer> listA = KMP.search(s, a);
        List<Integer> listB = KMP.search(s, b);
        List<Integer> ans = new ArrayList<>();
        while (!listA.isEmpty() && !listB.isEmpty()) {
            while (!listB.isEmpty() && listB.get(0) < listA.get(0) - k) {
                listB.remove(0);
            }
            if (!listB.isEmpty() && Math.abs(listA.get(0) - listB.get(0)) <= k) {
                ans.add(listA.get(0));
            }
            listA.remove(0);
        }
        return ans;
    }
}