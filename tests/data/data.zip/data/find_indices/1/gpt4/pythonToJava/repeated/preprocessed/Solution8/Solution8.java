import java.util.*;
import java.io.*;
import java.util.stream.*;
class Solution8 {
    public List<Integer> beautifulIndices(String s, String a, String b, int k) {
        List<Integer> aList = KMP.search(s, a);
        List<Integer> bList = KMP.search(s, b);
        List<Integer> ans = new ArrayList<>();
        while(!aList.isEmpty() && !bList.isEmpty()) {
            while(!bList.isEmpty() && bList.get(0) < aList.get(0) - k) {
                bList.remove(0);
            }
            if(!bList.isEmpty() && Math.abs(aList.get(0) - bList.get(0)) <= k) {
                ans.add(aList.get(0));
            }
            aList.remove(0);
        }
        return ans;
    }
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String s = scanner.next();
        String a = scanner.next();
        String b = scanner.next();
        int k = scanner.nextInt();
        Solution8 solution = new Solution8();
        List<Integer> beautiful_indices = solution.beautifulIndices(s, a, b, k);
        System.out.println(beautiful_indices);
    }
}