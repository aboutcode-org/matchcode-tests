import java.util.*;
import java.io.*;
import java.util.stream.*;
class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        // Assuming the input format will be "s a b k"
        String s = sc.nextLine();
        String a = sc.nextLine();
        String b = sc.nextLine();
        int k = sc.nextInt();
        Solution solution = new Solution();
        List<Integer> beautiful_indices = solution.beautifulIndices(s, a, b, k);
        for (Integer index : beautiful_indices) {
            System.out.println(index);
        }
        sc.close();
    }
}