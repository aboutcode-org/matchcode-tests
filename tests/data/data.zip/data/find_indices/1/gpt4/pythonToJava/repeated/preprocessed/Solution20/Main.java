import java.util.*;
import java.io.*;
import java.util.stream.*;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String[] input = sc.nextLine().split(" ");
        String s = input[0];
        String a = input[1];
        String b = input[2];
        int k = Integer.parseInt(input[3]);
        List<Integer> indicesA = KMP.search(s, a);
        List<Integer> indicesB = KMP.search(s, b);
        List<Integer> beautifulIndices = new ArrayList<>();
        while (!indicesA.isEmpty() && !indicesB.isEmpty()) {
            while (!indicesB.isEmpty() && indicesB.get(0) < indicesA.get(0) - k) {
                indicesB.remove(0);
            }
            if (!indicesB.isEmpty() && Math.abs(indicesA.get(0) - indicesB.get(0)) <= k) {
                beautifulIndices.add(indicesA.get(0));
            }
            indicesA.remove(0);
        }
        System.out.println(beautifulIndices);
    }
}