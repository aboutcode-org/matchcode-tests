import java.util.*;
import java.io.*;
import java.util.stream.*;
public class Solution3 {
    static int[] getPartialArray(char[] pattern) {
        int[] partialArray = new int[pattern.length];
        int j=0;
        for(int i=1;i<pattern.length;i++) {
            if(pattern[i]==pattern[j]) {
                j++;
                partialArray[i]=j;
            } else {
                if(j!=0) {
                    j = partialArray[j-1];
                    i--;
                } else {
                    partialArray[i]=0;
                }
            }
        }
        return partialArray;
    }
    static List<Integer> KMPSearch(char[] text, char[] pattern) {
        List<Integer> result = new ArrayList<>();
        int i=0, j=0;
        int[] partialArray = getPartialArray(pattern);
        while(i<text.length) {
            if(text[i]==pattern[j]) {
                i++;
                j++;
            }
            if(j==pattern.length) {
                result.add((i-j)+1);
                if(j!=0) {
                    j = partialArray[j-1];
                }
            } else if(i<text.length && text[i]!=pattern[j]) {
                if(j!=0) {
                    j = partialArray[j-1];
                } else {
                    i++;
                }
            }
        }
        return result;
    }
    static List<Integer> beautifulIndixes(String text, String pattern1, String pattern2, int limit) {
        List<Integer> pattern1Indixes=KMPSearch(text.toCharArray(), pattern1.toCharArray());
        List<Integer> pattern2Indixes=KMPSearch(text.toCharArray(), pattern2.toCharArray());
        List<Integer> result = new ArrayList<>();
        int j=0;
        for(int i=0;i<pattern1Indixes.size();i++) {
            while(j<pattern2Indixes.size() && pattern2Indixes.get(j)<pattern1Indixes.get(i)-limit) {
                j++;
            }
            if(j<pattern2Indixes.size() && Math.abs(pattern1Indixes.get(i)-pattern2Indixes.get(j))<=limit) {
                result.add(pattern1Indixes.get(i));
            }
        }
        return result;
    }
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String text = scanner.nextLine();
        String pattern1 = scanner.nextLine();
        String pattern2 = scanner.nextLine();
        int limit = scanner.nextInt();
        List<Integer> beautifulIndices = beautifulIndices(text, pattern1, pattern2, limit);
        System.out.println(beautifulIndices);
        scanner.close();
    }
}