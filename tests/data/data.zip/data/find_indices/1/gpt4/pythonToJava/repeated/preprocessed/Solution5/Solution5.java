import java.util.*;
import java.io.*;
import java.util.stream.*;
public class Solution5 {
    static int[] partial(String pattern) {
        int[] table = new int[pattern.length()];
        int j = 0;
        for (int i = 1; i < pattern.length(); i++) {
            while (j > 0 && pattern.charAt(j) != pattern.charAt(i)) {
                j = table[j-1];
            }
            if (pattern.charAt(i) == pattern.charAt(j)) j++;
            table[i] = j;
        }
        return table;
    }
    static Queue<Integer> search(String T, String P) {
        Queue<Integer> ret = new LinkedList<>();
        int[] partial = partial(P);
        int j = 0;
        for (int i = 0; i < T.length(); i++) {
            while (j > 0 && T.charAt(i) != P.charAt(j)) {
                j = partial[j-1];
            }
            if (T.charAt(i) == P.charAt(j)) j++;
            if (j == P.length()) { 
                ret.add(i - P.length() + 1);
                j = partial[j-1];
            }
        }
        return ret;
    }
    public List<Integer> beautifulIndices(String s, String a, String b, int k) throws Exception {
        Queue<Integer> queueA = search(s, a), queueB = search(s, b);
        List<Integer> ans = new ArrayList<>();
        while (!queueA.isEmpty() && !queueB.isEmpty()) {
            while (!queueB.isEmpty() && queueB.peek() < queueA.peek() - k) {
                queueB.poll();
            }
            if (!queueB.isEmpty() && Math.abs(queueA.peek() - queueB.peek()) <= k) {
                ans.add(queueA.peek());
            }
            queueA.poll();
        }
        return ans;
    }
    public static void main(String[] args) throws Exception {
        Scanner scanner = new Scanner(System.in);
        String s = scanner.next();
        String a = scanner.next();
        String b = scanner.next();
        int k = scanner.nextInt();
        Solution5 solution = new Solution5();
        List<Integer> beautiful_indices = solution.beautifulIndices(s, a, b, k);
        System.out.println(beautiful_indices);
    }
}