import java.util.*;
import java.io.*;
import java.util.stream.*;
class Solution {
    List<Integer> beautifulIndices(String s, String a, String b, int k) {
        Deque<Integer> queue1 = KMP.search(s, a);
        Deque<Integer> queue2 = KMP.search(s, b);
        List<Integer> ans = new ArrayList<>();
        while (!queue1.isEmpty() && !queue2.isEmpty()) {
            while (!queue2.isEmpty() && queue2.peekFirst() < queue1.peekFirst() - k)
                queue2.removeFirst();
            if (!queue2.isEmpty() && Math.abs(queue1.peekFirst() - queue2.peekFirst()) <= k)
                ans.add(queue1.peekFirst());
            queue1.removeFirst();
        }
        return ans;
    }
}