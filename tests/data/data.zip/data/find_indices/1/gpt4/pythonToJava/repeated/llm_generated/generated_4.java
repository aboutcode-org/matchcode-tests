Here is the Java semantic code clone of the provided Python code.

```java
import java.util.*;

public class KMP {
    public static int[] partial(String pattern) {
        int[] ret = {0};
        for (int i = 1; i < pattern.length(); i++) {
            int j = ret[i - 1];
            while (j > 0 && pattern.charAt(j) != pattern.charAt(i)) {
                j = ret[j - 1];
            }
            if (pattern.charAt(j) == pattern.charAt(i)) {
                ret[i] = j + 1;
            } else {
                ret[i] = j;
            }
        }
        return ret;
    }

    public static List<Integer> search(String T, String P) {
        int[] partial = KMP.partial(P);
        List<Integer> ret = new ArrayList<>();
        int j = 0;
        for (int i = 0; i < T.length(); i++) {
            while (j > 0 && T.charAt(i) != P.charAt(j)) {
                j = partial[j - 1];
            }
            if (T.charAt(i) == P.charAt(j)) {
                j++;
            }
            if (j == P.length()) {
                ret.add(i - (j - 1));
                j = partial[j - 1];
            }
        }
        return ret;
    }
}

class Solution {
    public List<Integer> beautifulIndices(String s, String a, String b, int k) {
        List<Integer> listA = KMP.search(s, a);
        List<Integer> listB = KMP.search(s, b);

        List<Integer> ans = new ArrayList<>();

        while (!listA.isEmpty() && !listB.isEmpty()) {
            while (!listB.isEmpty() && listB.get(0) < listA.get(0) - k) {
                listB.remove(0);
            }
            if (!listB.isEmpty() && Math.abs(listA.get(0) - listB.get(0)) <= k) {
                ans.add(listA.get(0));
            }
            listA.remove(0);
        }

        return ans;
    }
}

class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String s = scanner.nextLine();  // Assuming the input string is in the same order: "s a b k"
        String a = scanner.nextLine();
        String b = scanner.nextLine();
        int k = scanner.nextInt();

        Solution solution = new Solution();
        List<Integer> beautifulIndices = solution.beautifulIndices(s, a, b, k);
        System.out.println(beautifulIndices);
    }
}
```
Please notice that because Java doesn't support tuples and multiple return types like Python, I returned the search result as a list. The "deque" in Python is similar to "ArrayList" in Java, considering the usage in this scenario.