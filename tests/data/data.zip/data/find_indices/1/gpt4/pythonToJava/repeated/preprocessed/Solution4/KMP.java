import java.util.*;
import java.io.*;
import java.util.stream.*;
public class KMP {
    public static int[] partial(String pattern) {
        int[] ret = {0};
        for (int i = 1; i < pattern.length(); i++) {
            int j = ret[i - 1];
            while (j > 0 && pattern.charAt(j) != pattern.charAt(i)) {
                j = ret[j - 1];
            }
            if (pattern.charAt(j) == pattern.charAt(i)) {
                ret[i] = j + 1;
            } else {
                ret[i] = j;
            }
        }
        return ret;
    }
    public static List<Integer> search(String T, String P) {
        int[] partial = KMP.partial(P);
        List<Integer> ret = new ArrayList<>();
        int j = 0;
        for (int i = 0; i < T.length(); i++) {
            while (j > 0 && T.charAt(i) != P.charAt(j)) {
                j = partial[j - 1];
            }
            if (T.charAt(i) == P.charAt(j)) {
                j++;
            }
            if (j == P.length()) {
                ret.add(i - (j - 1));
                j = partial[j - 1];
            }
        }
        return ret;
    }
}