Here is the Java semantic code clone of the given Python code:

```java
import java.util.*;

class KMP {
    static int[] partial(String pattern) {
        // Calculate partial match table
        int[] ret = new int[pattern.length()];
        ret[0] = 0;

        for(int i = 1; i < pattern.length(); i++) {
            int j = ret[i - 1];
            while(j > 0 && pattern.charAt(j) != pattern.charAt(i)) {
                j = ret[j - 1];
            }

            ret[i] = (j + 1 if pattern.charAt(j) == pattern.charAt(i) else j);
        }

        return ret;
    }

    static List<Integer> search(String T, String P) {
        // KMP search main algorithm
        int[] partial = KMP.partial(P);
        List<Integer> ret = new ArrayList<>();
        int j = 0;

        for(int i = 0; i < T.length(); i++) {
            while(j > 0 && T.charAt(i) != P.charAt(j)) {
                j = partial[j - 1];
            }

            if(T.charAt(i) == P.charAt(j)) j++;

            if(j == P.length()) {
                ret.add(i - (j - 1));
                j = partial[j - 1];
            }
        }

        return ret;
    }
}

class Solution {
    public List<Integer> beautifulIndices(String s, String a, String b, int k) {
        List<Integer> aList = KMP.search(s, a);
        List<Integer> bList = KMP.search(s, b);
        List<Integer> ans = new ArrayList<>();

        while(!aList.isEmpty() && !bList.isEmpty()) {
            while(!bList.isEmpty() && bList.get(0) < aList.get(0) - k) {
                bList.remove(0);
            }

            if(!bList.isEmpty() && Math.abs(aList.get(0) - bList.get(0)) <= k) {
                ans.add(aList.get(0));
            }

            aList.remove(0);
        }

        return ans;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String s = scanner.next();
        String a = scanner.next();
        String b = scanner.next();
        int k = scanner.nextInt();

        Solution solution = new Solution();
        List<Integer> beautiful_indices = solution.beautifulIndices(s, a, b, k);
        System.out.println(beautiful_indices);
    }
}
```

Please note that there are semantic differences between Python and Java, for instance the way indexing and removal of list elements is performed, as well as the fact that Java uses the `Math.abs` function to calculate absolute values.