Below is a Java semantic code clone of the given Python code:

```Java
import java.util.*;

class KMP {
    public static int[] partial(char[] pattern) {
        int[] ret = new int[pattern.length];

        for (int i = 1; i < pattern.length; i++) {
            int j = ret[i - 1];
            while (j > 0 && pattern[j] != pattern[i]) {
                j = ret[j - 1];
            }
            ret[i] = (pattern[j] == pattern[i] ? j + 1 : j);
        }
        return ret;
    }

    public static List<Integer> search(char[] T, char[] P) {
        int[] partial = partial(P);
        List<Integer> ret = new LinkedList<>();
        int j = 0;

        for (int i = 0; i < T.length; i++) {
            while (j > 0 && T[i] != P[j]) {
                j = partial[j - 1];
            }
            if (T[i] == P[j]) {
                j++;
            }
            if (j == P.length) {
                ret.add(i - (j - 1));
                j = partial[j - 1];
            }
        }
        return ret;
    }
}

class Solution {
    public List<Integer> beautifulIndices(String s, String a, String b, int k) {
        Queue<Integer> aIndices = new LinkedList<>(KMP.search(s.toCharArray(), a.toCharArray()));
        Queue<Integer> bIndices = new LinkedList<>(KMP.search(s.toCharArray(), b.toCharArray()));
        List<Integer> ans = new ArrayList<>();

        while (!aIndices.isEmpty() && !bIndices.isEmpty()) {
            while (!bIndices.isEmpty() && bIndices.peek() < aIndices.peek() - k) {
                bIndices.poll();
            }
            if (!bIndices.isEmpty() && Math.abs(aIndices.peek() - bIndices.peek()) <= k) {
                ans.add(aIndices.peek());
            }
            aIndices.poll();
        }
        return ans;
    }
}

class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String s = sc.next();
        String a = sc.next();
        String b = sc.next();
        int k = sc.nextInt();

        Solution solution = new Solution();
        List<Integer> beautifulIndices = solution.beautifulIndices(s, a, b, k);
        System.out.println(beautifulIndices);
    }
}
```
Note: The input to the Java program is the same as the Python program, that is "s a b k". Each of s, a, b are strings and k is an integer. This must be entered in a single line separated by spaces.