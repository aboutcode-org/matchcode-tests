import java.util.*;
import java.io.*;
import java.util.stream.*;
class KMP {
    static int[] getLPS(String str) {
        int[] lps = new int[str.length()];
        int len = 0;
        int i = 1;
        lps[0] = 0;
        while (i < str.length()) {
            if (str.charAt(i) == str.charAt(len)) {
                len++;
                lps[i] = len;
                i++;
            } else {
                if (len != 0) {
                    len = lps[len - 1];
                } else {
                    lps[i] = len;
                    i++;
                }
            }
        }
        return lps;
    }
    static Deque<Integer> search(String txt, String pat) {
        int M = pat.length();
        int N = txt.length();
        int[] lps = getLPS(pat);
        int i = 0;
        int j = 0;
        Deque<Integer> ret = new ArrayDeque<>();
        while (i < N) {
            if (pat.charAt(j) == txt.charAt(i)) {
                j++;
                i++;
            }
            if (j == M) {
                ret.add(i - j);
                j = lps[j - 1];
            } else if (i < N && pat.charAt(j) != txt.charAt(i)) {
                if (j != 0)
                    j = lps[j - 1];
                    i = i + 1;
            }
        }
        return ret;
    }
}