Here is a rough Java translation:

```java
import java.util.*;

class KMP {
    ArrayList<Integer> partial(String pattern) {
        ArrayList<Integer> ret = new ArrayList<>();
        ret.add(0);

        for (int i = 1; i < pattern.length(); i++) {
            int j = ret.get(i - 1);
            while (j > 0 && pattern.charAt(j) != pattern.charAt(i)) {
                j = ret.get(j - 1);
            }
            ret.add((pattern.charAt(j) == pattern.charAt(i)) ? j + 1 : j);
        }
        return ret;
    }

    LinkedList<Integer> search(String T, String P) {
        ArrayList<Integer> partial = partial(P);
        LinkedList<Integer> ret = new LinkedList<>();
        int j = 0;

        for (int i = 0; i < T.length(); i++) {
            while (j > 0 && T.charAt(i) != P.charAt(j)) {
                j = partial.get(j - 1);
            }
            if (T.charAt(i) == P.charAt(j)) {
                j++;
            }
            if (j == P.length()) {
                ret.add(i - (j - 1));
                j = partial.get(j - 1);
            }
        }
        return ret;
    }
}

public class Solution {
    public ArrayList<Integer> beautifulIndices(String s, String a, String b, int k) {

        KMP kmp = new KMP();

        LinkedList<Integer> aIndices = kmp.search(s, a);
        LinkedList<Integer> bIndices = kmp.search(s, b);
        ArrayList<Integer> ans = new ArrayList<>();

        while (!aIndices.isEmpty() && !bIndices.isEmpty()) {
            while (!bIndices.isEmpty() && bIndices.peek() < aIndices.peek() - k) {
                bIndices.poll();
            }
            if (!bIndices.isEmpty() && Math.abs(aIndices.peek() - bIndices.peek()) <= k) {
                ans.add(aIndices.peek());
            }
            aIndices.poll();
        }
        return ans;
    }

    public static void main(String[] args) {
        // Expecting the user input to be: s a b k
        Scanner input = new Scanner(System.in);
        String s = input.next();
        String a = input.next();
        String b = input.next();
        int k = input.nextInt();

        Solution solution = new Solution();
        ArrayList<Integer> beautifulIndices = solution.beautifulIndices(s, a, b, k);
        System.out.println(beautifulIndices);
    }
}
```

Please note that Python's deque is translated to Java's LinkedList (as both supports addFirst, addLast, pollFirst, pollLast methods). The Python 'str.rsplit()' method is translated to 'Scanner.next()' method calls to achieve the same function.

Since Java has no native support for tuple, so a class is used to represent the partials (versus a single list in Python). This is done to follow Java's conventions better (although it does make it a bit less direct of a translation).