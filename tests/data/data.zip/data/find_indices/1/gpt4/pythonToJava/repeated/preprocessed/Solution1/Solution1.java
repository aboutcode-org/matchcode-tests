import java.util.*;
import java.io.*;
import java.util.stream.*;
class Solution1 {
    public List<Integer> beautifulIndices(String s, String a, String b, int k) {
      Deque<Integer> A = KMP.search(s, a);
      Deque<Integer> B = KMP.search(s, b);
      List<Integer> ans = new ArrayList<>();
      while (!A.isEmpty() && !B.isEmpty()) {
        while (!B.isEmpty() && B.peek() < A.peek() - k) {
          B.poll();
        }
        if (!B.isEmpty() && Math.abs(A.peek() - B.peek()) <= k) {
          ans.add(A.peek());
        }
        A.poll();
      }
      return ans;
    }
  }
  public static void main(String[] args) {
    // Assuming the input format is "s a b k"
    Scanner scanner = new Scanner(System.in);
    String inputString = scanner.nextLine();
    String[] parts = inputString.split(" ");
    String s = parts[0];
    String a = parts[1];
    String b = parts[2];
    int k = Integer.parseInt(parts[3]);
    Solution1 solution = new Solution1();
    List<Integer> beautifulIndices = solution.beautifulIndices(s, a, b, k);
    System.out.println(beautifulIndices);
  }
}
}