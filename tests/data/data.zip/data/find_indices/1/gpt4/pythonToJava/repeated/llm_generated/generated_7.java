```java
import java.util.*;

public class KMP {

    public static List<Integer> calculatePartialPattern(String pattern) {
        List<Integer> partialPattern = new ArrayList<>();
        partialPattern.add(0);

        for (int i = 1; i < pattern.length(); i++) {
            int j = partialPattern.get(i - 1);

            while (j > 0 && pattern.charAt(j) != pattern.charAt(i)) {
                j = partialPattern.get(j - 1);
            }

            partialPattern.add(j + 1);
        }

        return partialPattern;
    }

    public static LinkedList<Integer> search(String T, String P) {
        List<Integer> partialPattern = calculatePartialPattern(P);
        LinkedList<Integer> matches = new LinkedList<>();
        int j = 0;

        for (int i = 0; i < T.length(); i++) {
            while (j > 0 && T.charAt(i) != P.charAt(j)) {
                j = partialPattern.get(j - 1);
            }
            if (T.charAt(i) == P.charAt(j)) j++;
            if (j == P.length()) {
                matches.add(i - j + 1);
                j = partialPattern.get(j - 1);
            }
        }

        return matches;
    }
}

public class Solution {
    public static List<Integer> beautifulIndices(String s, String a, String b, int k) {
        LinkedList<Integer> patternAIndices = KMP.search(s, a);
        LinkedList<Integer> patternBIndices = KMP.search(s, b);
        ArrayList<Integer> beautifulIndices = new ArrayList<>();

        while (!patternAIndices.isEmpty() && !patternBIndices.isEmpty()) {
            while (!patternBIndices.isEmpty() && patternBIndices.getFirst() < patternAIndices.getFirst() - k) {
                patternBIndices.removeFirst();
            }

            if (!patternBIndices.isEmpty() && Math.abs(patternAIndices.getFirst() - patternBIndices.getFirst()) <= k) {
                beautifulIndices.add(patternAIndices.getFirst());
            }

            patternAIndices.removeFirst();
        }

        return beautifulIndices;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        String a = sc.nextLine();
        String b = sc.nextLine();
        int k = sc.nextInt();
        List<Integer> beautifulIndices = beautifulIndices(s, a, b, k);

        for (Integer index : beautifulIndices) {
            System.out.println(index);
        }
    }
}
```