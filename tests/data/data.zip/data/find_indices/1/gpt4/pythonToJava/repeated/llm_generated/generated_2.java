Here is the Java equivalent code of the Python code you've provided:

```java
import java.util.*;

class KMP {
    static int[] getLPSArray(String str) {
        int[] lps = new int[str.length()];
        int len = 0;

        lps[0] = 0;
        int i = 1;

        while (i < str.length()) {
            if (str.charAt(i) == str.charAt(len)) {
                len++;
                lps[i] = len;
                i++;
            } else {
                if (len != 0) {
                    len = lps[len - 1];
                } else {
                    lps[i] = len;
                    i++;
                }
            }
        }

        return lps;
    }

    static Deque<Integer> KMPSearch(String txt, String pat) {
        int[] lps = getLPSArray(pat);
        Deque<Integer> result = new ArrayDeque<>();
        int i = 0;
        int j = 0;

        while (i < txt.length()) {
            if (pat.charAt(j) == txt.charAt(i)) {
                i++;
                j++;
            }
            if (j == pat.length()) {
                result.add(i - j);
                if (j != 0) j = lps[j - 1];
            } else if (i < txt.length() && pat.charAt(j) != txt.charAt(i)) {
                if (j != 0) j = lps[j - 1];
                else i++;
            }
        }

        return result;
    }
}


class Solution {

    List<Integer> beautifulIndices(String s, String a, String b, int k) {
        Deque<Integer> indicesA = KMP.KMPSearch(s, a);
        Deque<Integer> indicesB = KMP.KMPSearch(s, b);
        List<Integer> ans = new ArrayList<Integer>();

        while (!indicesA.isEmpty() && !indicesB.isEmpty()) {
            while (!indicesB.isEmpty() && indicesB.peekFirst() < indicesA.peekFirst() - k) {
                indicesB.pollFirst();
            }

            if (!indicesB.isEmpty() && Math.abs(indicesA.peekFirst() - indicesB.peekFirst()) <= k) {
                ans.add(indicesA.peekFirst());
            }

            indicesA.pollFirst();
        }

        return ans;
    }
}

class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        // Assuming the input format will be "s a b k"
        String s = sc.nextLine();
        String a = sc.nextLine();
        String b = sc.nextLine();
        int k = sc.nextInt();

        Solution solution = new Solution();
        List<Integer> beautiful_indices = solution.beautifulIndices(s, a, b, k);

        for (Integer index : beautiful_indices) {
            System.out.println(index);
        }
      
        sc.close();
    }
}
```

Please note that Python indexing is 0 based just like Java. So the indices returned by both the Python and the Java code will be the same.