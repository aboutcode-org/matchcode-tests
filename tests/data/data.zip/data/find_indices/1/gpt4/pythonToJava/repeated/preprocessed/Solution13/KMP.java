import java.util.*;
import java.io.*;
import java.util.stream.*;
class KMP {
    public static int[] partial(char[] pattern) {
        int[] ret = new int[pattern.length];
        for (int i = 1; i < pattern.length; i++) {
            int j = ret[i - 1];
            while (j > 0 && pattern[j] != pattern[i]) {
                j = ret[j - 1];
            }
            ret[i] = (pattern[j] == pattern[i] ? j + 1 : j);
        }
        return ret;
    }
    public static List<Integer> search(char[] T, char[] P) {
        int[] partial = partial(P);
        List<Integer> ret = new LinkedList<>();
        int j = 0;
        for (int i = 0; i < T.length; i++) {
            while (j > 0 && T[i] != P[j]) {
                j = partial[j - 1];
            }
            if (T[i] == P[j]) {
                j++;
            }
            if (j == P.length) {
                ret.add(i - (j - 1));
                j = partial[j - 1];
            }
        }
        return ret;
    }
}