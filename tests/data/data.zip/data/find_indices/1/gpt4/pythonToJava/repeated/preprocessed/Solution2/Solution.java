import java.util.*;
import java.io.*;
import java.util.stream.*;
class Solution {
    List<Integer> beautifulIndices(String s, String a, String b, int k) {
        Deque<Integer> indicesA = KMP.KMPSearch(s, a);
        Deque<Integer> indicesB = KMP.KMPSearch(s, b);
        List<Integer> ans = new ArrayList<Integer>();
        while (!indicesA.isEmpty() && !indicesB.isEmpty()) {
            while (!indicesB.isEmpty() && indicesB.peekFirst() < indicesA.peekFirst() - k) {
                indicesB.pollFirst();
            }
            if (!indicesB.isEmpty() && Math.abs(indicesA.peekFirst() - indicesB.peekFirst()) <= k) {
                ans.add(indicesA.peekFirst());
            }
            indicesA.pollFirst();
        }
        return ans;
    }
}