Below is the semantic equivalent code in Java:

```java
import java.util.*;

class KMP {
    public static int[] partial(String pattern) {

        int[] ret = new int[pattern.length()];
        for (int i = 1; i < pattern.length(); i++) {
            int j = ret[i - 1];
            while (j > 0 && pattern.charAt(j) != pattern.charAt(i)) {
                j = ret[j - 1];
            }
            ret[i] = pattern.charAt(j) == pattern.charAt(i) ? j + 1 : j;
        }
        return ret;
    }

    public static List<Integer> search(String txt, String pat) {
        int[] partialArray = KMP.partial(pat);
        List<Integer> ret = new ArrayList<>();
        int j = 0;

        for (int i = 0; i < txt.length(); i++) {
            while(j > 0 && txt.charAt(i) != pat.charAt(j)) {
                j = partialArray[j - 1];
            }
            if(txt.charAt(i) == pat.charAt(j)) ++j;
            if(j == pat.length()){
                ret.add(i - (j - 1));
                j = partialArray[j - 1];
            }
        }
        return ret;
    }
}

public class Solution {
    public List<Integer> beautifulIndices(String s, String a, String b, int k) {

        List<Integer> aList = KMP.search(s, a);
        List<Integer> bList = KMP.search(s, b);
        List<Integer> ans = new ArrayList<>();

        while (!aList.isEmpty() && !bList.isEmpty()) {
            while (!bList.isEmpty() && bList.get(0) < aList.get(0) - k) {
                bList.remove(0);
            }
            if(!bList.isEmpty() && Math.abs(aList.get(0) - bList.get(0)) <= k){
                ans.add(aList.get(0));
            }
            aList.remove(0);
        }
        return ans;
    }
}

public static void main(String args[]) {
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter input: ");
    String s = sc.nextLine();
    String a = sc.nextLine();
    String b = sc.nextLine();
    int k = sc.nextInt();

    Solution solution = new Solution();
    List<Integer> beautifulIndices = solution.beautifulIndices(s, a, b, k);
    System.out.println(beautifulIndices);
}
```
Remember to change the inputs to match with how the main method fetches them.
Remember to run the main method from outside the Solution class in Java.