import java.util.*;
import java.io.*;
import java.util.stream.*;
public class Main {
    // Main Method
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        String a = sc.nextLine();
        String b = sc.nextLine();
        int k = sc.nextInt();
        Solution solution = new Solution();
        List<Integer> beautifulIndices = solution.beautifulIndices(s, a, b, k);
        System.out.println(beautifulIndices);
    }
}