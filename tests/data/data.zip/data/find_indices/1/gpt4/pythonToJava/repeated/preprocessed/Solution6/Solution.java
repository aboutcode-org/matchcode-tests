import java.util.*;
import java.io.*;
import java.util.stream.*;
class Solution {
    public List<Integer> beautifulIndices(String s, String a, String b, int k) {
        Deque<Integer> dequeA = KMP.search(s, a);
        Deque<Integer> dequeB = KMP.search(s, b);
        List<Integer> ans = new ArrayList<>();
        while (!dequeA.isEmpty() && !dequeB.isEmpty()) {
            while (!dequeB.isEmpty() && dequeB.peekFirst() < dequeA.peekFirst() - k) {
                dequeB.removeFirst();
            }
            if (!dequeB.isEmpty() && Math.abs(dequeA.peekFirst() - dequeB.peekFirst()) <= k) {
                ans.add(dequeA.peekFirst());
            }
            dequeA.removeFirst();
        }
        return ans;
    }
}