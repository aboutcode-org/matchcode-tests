import java.util.*;
import java.io.*;
import java.util.stream.*;
class Solution {
    public List<Integer> beautifulIndices(String s, String a, String b, int k) {
        KMP kmp = new KMP();
        Deque<Integer> aMatches = kmp.search(s, a), bMatches = kmp.search(s, b);
        List<Integer> ans = new ArrayList<>();
        while(!aMatches.isEmpty() && !bMatches.isEmpty()){
            while(!bMatches.isEmpty() && bMatches.peek() < aMatches.peek() - k)
                bMatches.pop();
            if (!bMatches.isEmpty() && Math.abs(aMatches.peek() - bMatches.peek()) <= k)
                ans.add(aMatches.peek());
            aMatches.pop();
        }
        return ans;
    }
}