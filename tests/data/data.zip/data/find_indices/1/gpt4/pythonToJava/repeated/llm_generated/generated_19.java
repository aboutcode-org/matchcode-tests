Here is a Java code that captures similar semantics:

```java
import java.util.*;

class KMP {
    static int[] partial(String pattern) {
        int[] ret = new int[pattern.length()];

        for (int i = 1; i < pattern.length(); i++) {
            int j = ret[i - 1];
            while (j > 0 && pattern.charAt(j) != pattern.charAt(i)) {
                j = ret[j - 1];
            }
            ret[i] = (pattern.charAt(j) == pattern.charAt(i)) ? j + 1 : j;
        }
        return ret;
    }

    static Deque<Integer> search(String T, String P) {
        int[] partial = KMP.partial(P);
        Deque<Integer> ret = new LinkedList<>();
        int j = 0;

        for (int i = 0; i < T.length(); i++) {
            while (j > 0 && T.charAt(i) != P.charAt(j)) {
                j = partial[j - 1];
            }
            if (T.charAt(i) == P.charAt(j)) j++;
            if (j == P.length()) {
                ret.add(i - (j - 1));
                j = partial[j - 1];
            }
        }
        return ret;
    }
}

public class Solution {
    static List<Integer> beautifulIndices(String s, String a, String b, int k) {
        Deque<Integer> aPositions = KMP.search(s, a);
        Deque<Integer> bPositions = KMP.search(s, b);
        List<Integer> ans = new ArrayList<>();

        while (!aPositions.isEmpty() && !bPositions.isEmpty()) {
            while (!bPositions.isEmpty() && bPositions.getFirst() < aPositions.getFirst() - k) {
                bPositions.removeFirst();
            }
            if (!bPositions.isEmpty() && Math.abs(aPositions.getFirst() - bPositions.getFirst()) <= k) {
                ans.add(aPositions.getFirst());
            }
            aPositions.removeFirst();
        }

        return ans;
    }

    public static void main(String[] args) {
        // Assuming the input format is "s a b k"
        Scanner scanner = new Scanner(System.in);

        String s = scanner.next();
        String a = scanner.next();
        String b = scanner.next();
        int k = scanner.nextInt();

        List<Integer> beautifulIndices = beautifulIndices(s, a, b, k);
        for (int index : beautifulIndices) {
            System.out.println(index);
        }
        
        scanner.close();
    }
}
```

The KMP algorithm is correctly replicated in the Java implementation, as it is language-independent. In both versions, the exact locations of pattern matches are stored in a deque, allowing them to be efficiently popped off the front when they are no longer needed. 

For the `beautifulIndices` method, the approach is to keep removing elements from the `bPositions` deque until we find an element that is within k distance of the current `aPositions` element. If such an element is found, the current `aPositions` value is appended to the answers list. Then the current `aPositions` element is popped off, and the process is repeated until `aPositions` or `bPositions` deque is exhausted. 

In `main`, user inputs are read by a scanner, the `beautifulIndices` function is called, and its output is printed.