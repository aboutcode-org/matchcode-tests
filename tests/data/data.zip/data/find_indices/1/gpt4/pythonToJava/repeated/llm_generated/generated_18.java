Here is a Java semantic clone of the given Python code:

```java
import java.util.*;

class KMP {
    static int[] calculatePartialTable(String pattern) {
        int[] partialTable = new int[pattern.length()];

        for (int i = 1; i < pattern.length(); i++) {
            int j = partialTable[i - 1];
            while (j > 0 && pattern.charAt(j) != pattern.charAt(i)) {
                j = partialTable[j - 1];
            }
            partialTable[i] = pattern.charAt(j) == pattern.charAt(i) ? j+1 : j;
        }
        return partialTable;
    }

    static List<Integer> search(String target, String pattern) {
        int[] partialTable = calculatePartialTable(pattern);
        List<Integer> matches = new ArrayList<>();
        int j = 0;

        for (int i = 0; i < target.length(); i++) {
            while (j > 0 && target.charAt(i) != pattern.charAt(j)) {
                j = partialTable[j - 1];
            }
            if (target.charAt(i) == pattern.charAt(j)) {
                j++;
            }
            if (j == pattern.length()) {
                matches.add(i - j + 1);
                j = partialTable[j - 1];
            }
        }
        return matches;
    }
}

public class Main {
    static List<Integer> findBeautifulIndices(String s, String a, String b, int k) {
        List<Integer> matchPositionsForA = KMP.search(s, a);
        List<Integer> matchPositionsForB = KMP.search(s, b);
        List<Integer> beautifulIndices = new ArrayList<>();
        Collections.reverse(matchPositionsForA);
        Collections.reverse(matchPositionsForB);

        while (!matchPositionsForA.isEmpty() && !matchPositionsForB.isEmpty()) {
            while (!matchPositionsForB.isEmpty() && matchPositionsForB.get(matchPositionsForB.size() - 1) < matchPositionsForA.get(matchPositionsForA.size() - 1) - k) {
                matchPositionsForB.remove(matchPositionsForB.size() - 1);
            }
            if (!matchPositionsForB.isEmpty() && Math.abs(matchPositionsForA.get(matchPositionsForA.size() - 1) - matchPositionsForB.get(matchPositionsForB.size() - 1)) <= k) {
                beautifulIndices.add(matchPositionsForA.get(matchPositionsForA.size() - 1));
            }
            matchPositionsForA.remove(matchPositionsForA.size() - 1);
        }
        return beautifulIndices;
    }
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String s = scanner.next();
        String a = scanner.next();
        String b = scanner.next();
        int k = scanner.nextInt();
        List<Integer> beautifulIndices = findBeautifulIndices(s, a, b, k);
        for (int index : beautifulIndices) {
            System.out.println(index);
        }
        scanner.close();
    }
}
```

This Java code does the same operations as your Python code:
- The `KMP` class provides the KMP search algorithm.
- The `findBeautifulIndices` method in the `Main` class does the same operations as your `beautifulIndices` method.
- Inside the `main` method, user inputs are processed and the `findBeautifulIndices` method is invoked.