import java.util.*;
import java.io.*;
import java.util.stream.*;
public class Solution19 {
    static List<Integer> beautifulIndices(String s, String a, String b, int k) {
        Deque<Integer> aPositions = KMP.search(s, a);
        Deque<Integer> bPositions = KMP.search(s, b);
        List<Integer> ans = new ArrayList<>();
        while (!aPositions.isEmpty() && !bPositions.isEmpty()) {
            while (!bPositions.isEmpty() && bPositions.getFirst() < aPositions.getFirst() - k) {
                bPositions.removeFirst();
            }
            if (!bPositions.isEmpty() && Math.abs(aPositions.getFirst() - bPositions.getFirst()) <= k) {
                ans.add(aPositions.getFirst());
            }
            aPositions.removeFirst();
        }
        return ans;
    }
    public static void main(String[] args) {
        // Assuming the input format is "s a b k"
        Scanner scanner = new Scanner(System.in);
        String s = scanner.next();
        String a = scanner.next();
        String b = scanner.next();
        int k = scanner.nextInt();
        List<Integer> beautifulIndices = beautifulIndices(s, a, b, k);
        for (int index : beautifulIndices) {
            System.out.println(index);
        }
        scanner.close();
    }
}