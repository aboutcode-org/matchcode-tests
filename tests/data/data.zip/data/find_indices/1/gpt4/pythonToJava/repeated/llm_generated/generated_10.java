Here is the equivalent Java implementation of the code provided:

```java
import java.util.*;

public class KMP {

    public static int[] partial(String pattern) {
        int[] ret = new int[pattern.length()];
        for(int i = 1; i < pattern.length(); i++) {
            int j = ret[i - 1];
            while(j > 0 && pattern.charAt(j) != pattern.charAt(i)) {
                j = ret[j - 1];
            }
            ret[i] = j + (pattern.charAt(j) == pattern.charAt(i) ? 1 : 0);
        }
        return ret;
    }

    public static List<Integer> search(String T, String P) {
        int[] partial = partial(P);
        List<Integer> ret = new ArrayList<>();
        int j = 0;
        for(int i = 0; i < T.length(); i++) {
            while(j > 0 && T.charAt(i) != P.charAt(j)) {
                j = partial[j - 1];
            }
            if(T.charAt(i) == P.charAt(j)) j++;
            if(j == P.length()) {
                ret.add(i - (j - 1));
                j = partial[j - 1];
            }
        }
        return ret;
    }

    public static List<Integer> beautifulIndices(String s, String a, String b, int k) {
        List<Integer> A = search(s, a);
        List<Integer> B = search(s, b);
        List<Integer> ans = new ArrayList<>();
        Iterator<Integer> iterA = A.iterator();
        Iterator<Integer> iterB = B.iterator();
        Integer posb = iterB.hasNext() ? iterB.next() : null;

        while(iterA.hasNext()){
            Integer posa = iterA.next();
            while(posb != null && posb < posa - k){
                posb = iterB.hasNext() ? iterB.next() : null;
            }
            if(posb != null && Math.abs(posa - posb) <= k){
                ans.add(posa);
            }
        }
        return ans;
    }

    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        String[] parts = scanner.nextLine().split(" ");
        String s = parts[0];
        String a = parts[1];
        String b = parts[2];
        int k = Integer.parseInt(parts[3]);
        List<Integer> beautiful_indices = beautifulIndices(s, a, b, k);
        System.out.println(beautiful_indices);     
        scanner.close();
    }
}
```
In this Java code, the collections 'deque' was replaced by ArrayList and added iterators to iterate over ArrayList. The built-in print function was replaced by System.out.println.