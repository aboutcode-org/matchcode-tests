Here is a semantic Java code clone for the given Python code:
```java
import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String inputString = scanner.nextLine();
        String[] parts = inputString.split(" ");
        String s = parts[0];
        String a = parts[1];
        String b = parts[2];
        int k = Integer.parseInt(parts[3]);

        Solution solution = new Solution();
        List<Integer> beautifulIndices = solution.beautifulIndices(s, a, b, k);
        System.out.println(beautifulIndices);
    }
}

class Solution {
    public List<Integer> beautifulIndices(String s, String a, String b, int k) {

        Deque<Integer> dequeA = KMP.search(s, a);
        Deque<Integer> dequeB = KMP.search(s, b);
        List<Integer> ans = new ArrayList<>();

        while (!dequeA.isEmpty() && !dequeB.isEmpty()) {
            while (!dequeB.isEmpty() && dequeB.peekFirst() < dequeA.peekFirst() - k) {
                dequeB.removeFirst();
            }

            if (!dequeB.isEmpty() && Math.abs(dequeA.peekFirst() - dequeB.peekFirst()) <= k) {
                ans.add(dequeA.peekFirst());
            }

            dequeA.removeFirst();
        }

        return ans;
    }
}


class KMP {
    static int[] getLPS(String str) {
        int[] lps = new int[str.length()];
        int len = 0;
        int i = 1;
        lps[0] = 0;
        while (i < str.length()) {
            if (str.charAt(i) == str.charAt(len)) {
                len++;
                lps[i] = len;
                i++;
            } else {
                if (len != 0) {
                    len = lps[len - 1];
                } else {
                    lps[i] = len;
                    i++;
                }
            }

        }
        return lps;
    }

    static Deque<Integer> search(String txt, String pat) {
        int M = pat.length();
        int N = txt.length();

        int[] lps = getLPS(pat);
        int i = 0;
        int j = 0;
        Deque<Integer> ret = new ArrayDeque<>();
        while (i < N) {
            if (pat.charAt(j) == txt.charAt(i)) {
                j++;
                i++;
            }
            if (j == M) {
                ret.add(i - j);
                j = lps[j - 1];
            } else if (i < N && pat.charAt(j) != txt.charAt(i)) {
                if (j != 0)
                    j = lps[j - 1];
                else
                    i = i + 1;
            }
        }
        return ret;
    }
}
```
This Java code mirrors the functionality of your Python code. The `getLPS()` method in the `KMP` class corresponds to the `partial()` method in your Python `KMP` class, and `beautifulIndices()` in `Solution` in the Java code corresponds to the same method in `Solution` of Python code. The `main()` method takes care of input receipt and code execution.