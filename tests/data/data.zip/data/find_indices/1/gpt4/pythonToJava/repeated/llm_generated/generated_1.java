// Java code clone of Python's Knuth–Morris–Pratt and a solution class
import java.util.*;

public class KMP {

  public static int[] partial(String pattern) {
    // Calculate partial match table
    int[] ret = new int[pattern.length()];

    for (int i = 1; i < pattern.length(); i++) {
      int j = ret[i - 1];
      while (j > 0 && pattern.charAt(j) != pattern.charAt(i)) {
        j = ret[j - 1];
      }
      ret[i] = pattern.charAt(j) == pattern.charAt(i) ? j + 1 : j;
    }
    return ret;
  }

  public static Deque<Integer> search(String T, String P) {
    // KMP search main algorithm: Return all matching positions
    int[] partial = KMP.partial(P);
    Deque<Integer> ret = new LinkedList<>();
    int j = 0;

    for (int i = 0; i < T.length(); i++) {
      while (j > 0 && T.charAt(i) != P.charAt(j)) {
        j = partial[j - 1];
      }
      if (T.charAt(i) == P.charAt(j)) {
        j++;
      }
      if (j == P.length()) {
        ret.add(i - (j - 1));
        j = partial[j - 1];
      }
    }
    return ret;
  }

  public static class Solution {

    public List<Integer> beautifulIndices(String s, String a, String b, int k) {

      Deque<Integer> A = KMP.search(s, a);
      Deque<Integer> B = KMP.search(s, b);
      List<Integer> ans = new ArrayList<>();

      while (!A.isEmpty() && !B.isEmpty()) {
        while (!B.isEmpty() && B.peek() < A.peek() - k) {
          B.poll();
        }
        if (!B.isEmpty() && Math.abs(A.peek() - B.peek()) <= k) {
          ans.add(A.peek());
        }
        A.poll();
      }
      return ans;
    }
  }
  
  public static void main(String[] args) {
    // Assuming the input format is "s a b k"
    Scanner scanner = new Scanner(System.in);
    String inputString = scanner.nextLine();
    
    String[] parts = inputString.split(" ");
    String s = parts[0];
    String a = parts[1];
    String b = parts[2];
    int k = Integer.parseInt(parts[3]);

    Solution solution = new Solution();
    List<Integer> beautifulIndices = solution.beautifulIndices(s, a, b, k);
    
    System.out.println(beautifulIndices);
  }
}