import java.util.*;
import java.io.*;
import java.util.stream.*;
public class Solution16 {
  public ArrayList<Integer> findBeautifulIndices(String str, String strA, String strB, int num) {
    TreeSet<Integer> indexShifts = new TreeSet<>(buildIndicesList(str, strB));
    ArrayList<Integer> beautifulIndices = new ArrayList<>();
    for (int currentIndex : buildIndicesList(str, strA)) {
      if (!indexShifts.subSet(currentIndex - num, currentIndex + num + 1).isEmpty()) {
        beautifulIndices.add(currentIndex);
      }
    }
    return beautifulIndices;
  }
  private ArrayList<Integer> buildIndicesList(String mainString, String patternString) {
    ArrayList<Integer> indexList = new ArrayList<>();
    int mainStrLength = mainString.length();
    int patternStrLength = patternString.length();
    for (int index = 0; index <= mainStrLength - patternStrLength; index++) {
      boolean patternFound = true;
      for (int internalIndex = 0; internalIndex < patternStrLength; internalIndex++) {
        if (patternString.charAt(internalIndex) != mainString.charAt(index + internalIndex)) {
          patternFound = false;
          break;
        }
      }
      if (patternFound) {
        indexList.add(index);
      }
    }
    return indexList;
  }
  public static void main(String[] cmdArgs) {
    Scanner inputScanner = new Scanner(System.in);
    String completeInputLine = inputScanner.nextLine();
    String[] parts = completeInputLine.split(" ");
    String str = parts[0];
    String strA = parts[1];
    String strB = completeInputLine.substring(str.length() + strA.length() + 2, completeInputLine.lastIndexOf(" "));
    int num = Integer.parseInt(parts[parts.length - 1]);
    Solution16 solutionObject = new Solution16();
    ArrayList<Integer> beautifulIndices = solutionObject.findBeautifulIndices(str, strA, strB, num);
    System.out.println(beautifulIndices);
  }
}