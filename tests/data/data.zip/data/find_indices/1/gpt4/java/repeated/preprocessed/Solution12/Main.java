import java.util.*;
import java.io.*;
import java.util.stream.*;
public class Main {
    public List<Integer> calculateBeautifulIndices(String str, String firstString, String secondString, int keyValue) {
        TreeSet<Integer> patternShifts = new TreeSet<>(construct(str, secondString));
        List<Integer> finalResult = new ArrayList<>();
        for (int index : construct(str, firstString)) {
            if (!patternShifts.subSet(index - keyValue, index + keyValue + 1).isEmpty()) {
                finalResult.add(index);
            }
        }
        return finalResult;
    }
    private List<Integer> construct(String textString, String ptn) {
        List<Integer> shiftsList = new ArrayList<>();
        int textLength = textString.length();
        int ptnLength = ptn.length();
        for (int i = 0; i <= textLength - ptnLength; i++) {
            boolean isMatched = true;
            for (int j = 0; j < ptnLength; j++) {
                if (ptn.charAt(j) != textString.charAt(i + j)) {
                    isMatched = false;
                    break;
                }
            }
            if (isMatched) {
                shiftsList.add(i);
            }
        }
        return shiftsList;
    }
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String readInput = in.nextLine(); 
        String[] splitInput = readInput.split(" ");
        String str = splitInput[0];
        String firstString = splitInput[1];
        String secondString = readInput.substring(str.length() + firstString.length() + 2, readInput.lastIndexOf(" "));
        int keyValue = Integer.parseInt(splitInput[splitInput.length - 1]);
        Main app = new Main();
        List<Integer> beautifulIndices = app.calculateBeautifulIndices(str, firstString, secondString, keyValue);
        System.out.println(beautifulIndices);
    }
}