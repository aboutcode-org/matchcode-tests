import java.util.*;
import java.io.*;
import java.util.stream.*;
public class Solution7 {
    public List<Integer> getBeautifulIndices(String str, String pattern1, String pattern2, int dist) {
        TreeSet<Integer> pattern2Indices = new TreeSet<>(locatePattern(str, pattern2));
        List<Integer> output = new ArrayList<>();
        for (int idx : locatePattern(str, pattern1)) {
            if (!pattern2Indices.subSet(idx - dist, idx + dist + 1).isEmpty()) {
                output.add(idx);
            }
        }
        return output;
    }
    private List<Integer> locatePattern(String inputStr, String searchStr) {
        List<Integer> patternLocations = new ArrayList<>();
        final int strLength = inputStr.length();
        final int patternLength = searchStr.length();
        for (int i = 0; i <= strLength - patternLength; i++) {
            boolean found = true;
            for (int j = 0; j < patternLength; j++) {
                if (searchStr.charAt(j) != inputStr.charAt(i + j)) {
                  found = false;
                  break;
                }
            }
            if (found) {
                patternLocations.add(i);
            }
        }
        return patternLocations;
    }
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        String userInput = scan.nextLine();
        String[] inputParts = userInput.split(" ");
        String str = inputParts[0];
        String pattern1 = inputParts[1];
        String pattern2 = userInput.substring(str.length() + pattern1.length() + 2, userInput.lastIndexOf(" "));
        int dist = Integer.parseInt(inputParts[inputParts.length - 1]);
        Solution7 indexer = new Solution7();
        List<Integer> beautifulIndices = indexer.getBeautifulIndices(str, pattern1, pattern2, dist);
        System.out.println(beautifulIndices);
    }
}