import java.util.*;
import java.io.*;
import java.util.stream.*;
public class Solution5 {
  public List<Integer> calculateBeautifulIndices(String s, String a, String b, int k) {
    TreeSet<Integer> patternShifts = new TreeSet<>(patternInString(s, b));
    List<Integer> beautifulIndices = new ArrayList<>();
    for (int ind : patternInString(s, a)) {
      if (!patternShifts.subSet(ind - k, ind + k + 1).isEmpty()) {
        beautifulIndices.add(ind);
      }
    }
    return beautifulIndices;
  }
  private List<Integer> patternInString(String text, String pattern) {
    List<Integer> shifts = new ArrayList<>();
    int textLength = text.length();
    int patternLength = pattern.length();
    for (int i = 0; i <= textLength - patternLength; i++) {
      boolean isPattern = true;
      for (int j = 0; j < patternLength; j++) {
        if (pattern.charAt(j) != text.charAt(i + j)) {
          isPattern = false;
          break;
        }
      }
      if (isPattern) {
        shifts.add(i);
      }
    }
    return shifts;
  }
  public static void main(String[] args) {
      Scanner inputReader = new Scanner(System.in);
      String inputLine = inputReader.nextLine();
      String[] splitInput = inputLine.split(" ");
      String s = splitInput[0];
      String a = splitInput[1];
      String b = inputLine.substring(s.length() + a.length() + 2, inputLine.lastIndexOf(" "));
      int k = Integer.parseInt(splitInput[splitInput.length - 1]);
      Solution5 taskSolution = new Solution5();
      List<Integer> calculatedIndices = taskSolution.calculateBeautifulIndices(s, a, b, k);
      System.out.println(calculatedIndices);
  }
}