import java.util.*;

public class CloneSolution {
  public List<Integer> getBeautifulIndices(String inputString, String firstString, String secondString, int range) {
    
    // Shift position of pattern secondString
    TreeSet<Integer> patternShiftPositions = new TreeSet<Integer>(findMatchesInString(inputString, secondString));
    ArrayList<Integer> beautifulIndicesList = new ArrayList<>();
    
    // Iterate patternShiftPositions for pattern firstString 
    for (int element : findMatchesInString(inputString, firstString)) {
      
      // Check availability of variable 'element' in range of [element - range, element + range + 1)
      if (!patternShiftPositions.subSet(element - range, element + range + 1).isEmpty()) {
        beautifulIndicesList.add(element);
      }
    }

    return beautifulIndicesList;
  }

  private List<Integer> findMatchesInString(String mainString, String subStringPattern) {
    ArrayList<Integer> matchPosList = new ArrayList<>();

    final int mainStringLength = mainString.length();
    final int subStringPatternLength = subStringPattern.length();
    
    for (int iterator = 0; iterator <= mainStringLength - subStringPatternLength; iterator++) {
      boolean isMatched = true;
      
      for (int iterator2 = 0; iterator2 < subStringPatternLength; iterator2++) {
        if (subStringPattern.charAt(iterator2) != mainString.charAt(iterator + iterator2)) {
          isMatched = false;
          break;
        }
      }

      if (isMatched) {
        matchPosList.add(iterator);
      }
    }

    return matchPosList;
  }

  public static void main(String[] args) {
    Scanner inputScan = new Scanner(System.in);
    String inputLine = inputScan.nextLine(); // Reading the entire input line

    // Spliiting input upon whitespaces
    String[] inputParts = inputLine.split(" ");

    // Extracting various parameters from the input parts
    String s = inputParts[0];
    String a = inputParts[1];
    String b = inputLine.substring(s.length() + a.length() + 2, inputLine.lastIndexOf(" "));
    int k = Integer.parseInt(inputParts[inputParts.length - 1]);

    // Creating a CloneSolution instance and calling its getBeautifulIndices method
    CloneSolution cloneObj = new CloneSolution();
    List<Integer> outputBeautifulIndices = cloneObj.getBeautifulIndices(s, a, b, k);

    // Showing beautiful indices as output
    System.out.println(outputBeautifulIndices);
  }
}