import java.util.*;
import java.io.*;
import java.util.stream.*;
public class Solution14 {
    public List<Integer> getBeautifulIndices(String word, String firstPattern, String secondPattern, int range) {
        TreeSet<Integer> shifts = new TreeSet<>(calculateShifts(word, secondPattern));
        ArrayList<Integer> indices = new ArrayList<>();
        for (int index : calculateShifts(word, firstPattern)) {
            // check if j exists within [index - range, index + range + 1)
            if (!shifts.subSet(index - range, index + range + 1).isEmpty()) {
                indices.add(index);
            }
        }
        return indices;
    }
    private List<Integer> calculateShifts(String text, String pattern) {
        ArrayList<Integer> indexList = new ArrayList<>();
        final int textLength = text.length();
        final int patternLength = pattern.length();
        for (int i = 0; i <= textLength - patternLength; i++) {
            boolean isMatch = true;
            for (int j = 0; j < patternLength; j++) {
                if (pattern.charAt(j) != text.charAt(i + j)) {
                    isMatch = false;
                    break;
                }
            }
            if (isMatch) {
                indexList.add(i);
            }
        }
        return indexList;
    }
    public static void main(String[] arguments) {
        Scanner scanner = new Scanner(System.in);
        String inputString = scanner.nextLine(); // Reads the entire input line
        // Splitting the input string by spaces
        String[] inputParts = inputString.split(" ");
        // Getting data from the inputParts
        String word = inputParts[0];
        String firstPattern = inputParts[1];
        String secondPattern = inputString.substring(word.length() + firstPattern.length() + 2, inputString.lastIndexOf(" "));
        int range = Integer.parseInt(inputParts[inputParts.length - 1]);
        Solution14 bi = new Solution14();
        List<Integer> beautifulIndices = bi.getBeautifulIndices(word, firstPattern, secondPattern, range);
        System.out.println(beautifulIndices);
    }
}