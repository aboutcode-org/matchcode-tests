import java.util.*;
import java.io.*;
import java.util.stream.*;
public class Solution4 {
    public List<Integer> findBeautifulIndices(String str, String pattern1, String pattern2, int limit) {
        TreeSet<Integer> patternShifts = new TreeSet<>(extractIndices(str, pattern2));
        List<Integer> beautifulIndices = new ArrayList<>();
        for (int index : extractIndices(str, pattern1)) {
            if (!patternShifts.subSet(index - limit, index + limit + 1).isEmpty()) {
                beautifulIndices.add(index);
            }
        }
        return beautifulIndices;
    }
    private List<Integer> extractIndices(String source, String target) {
        List<Integer> shifts = new ArrayList<>();
        final int sourceLength = source.length();
        final int targetLength = target.length();
        for (int i = 0; i <= sourceLength - targetLength; i++) {
            boolean isMatch = true;
            for (int j = 0; j < targetLength; j++) {
                if (target.charAt(j) != source.charAt(i + j)) {
                    isMatch = false;
                    break;
                }
            }
            if (isMatch) {
                shifts.add(i);
            }
        }
        return shifts;
    }
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String line = scanner.nextLine();
        String[] elements = line.split("\\s");
        String sourceString = elements[0];
        String pattern1 = elements[1];
        String pattern2 = line.substring(sourceString.length() + pattern1.length() + 2, line.lastIndexOf(" "));
        int limit = Integer.parseInt(elements[elements.length - 1]);
        Solution4 solver = new Solution4();
        List<Integer> beautifulIndices = solver.findBeautifulIndices(sourceString, pattern1, pattern2, limit);
        System.out.println(beautifulIndices);
    }
}