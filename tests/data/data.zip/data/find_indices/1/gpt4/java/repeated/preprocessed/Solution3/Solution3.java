import java.util.*;
import java.io.*;
import java.util.stream.*;
public class Solution3 {
  public ArrayList<Integer> findRavishingIndexes(String str, String first, String second, int range) {
    TreeSet<Integer> beautifulShifts = new TreeSet<>(locateOccurrences(str, second));
    ArrayList<Integer> output = new ArrayList<>();
    for (int index : locateOccurrences(str, first)) {
      if (!beautifulShifts.subSet(index - range, index + range + 1).isEmpty()) {
        output.add(index);
      }
    }
    return output;
  }
  private ArrayList<Integer> locateOccurrences(String context, String fragment) {
    ArrayList<Integer> indicesOfFragment = new ArrayList<>();
    final int contextLength = context.length();
    final int fragmentLength = fragment.length();
    for (int index = 0; index <= contextLength - fragmentLength; ++index) {
      boolean matchingPattern = true;
      for (int subIndex = 0; subIndex < fragmentLength; ++subIndex) {
        if (context.charAt(index + subIndex) != fragment.charAt(subIndex)) {
            matchingPattern = false;
            break;
        }
      }
      if (matchingPattern) {
        indicesOfFragment.add(index);
      }
    }
    return indicesOfFragment;
  }
    public static void main(String[] args) {
        System.out.println("Enter your inputs");
        Scanner scan = new Scanner(System.in);
        String entireInput = scan.nextLine();
        String[] splitInput = entireInput.split(" ");
        String str = splitInput[0];
        String first = splitInput[1];
        String lastSpace = splitInput[splitInput.length - 1];
        int range = Integer.parseInt(lastSpace);
        String second = entireInput.substring(str.length() + first.length() + 2, entireInput.length() - lastSpace.length() -1);       
        Solution3 clone = new Solution3();
        ArrayList<Integer> ravishingIndexes = clone.findRavishingIndexes(str, first, second, range);
        System.out.println("Ravishing Indices are: "+ ravishingIndexes);
    }
}