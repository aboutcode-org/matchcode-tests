import java.util.*;

class DifferentSolution {
  public List<Integer> generateBeautifulIndices(String str, String part1, String part2, int num) {
    TreeSet<Integer> shiftsSet = new TreeSet<>(createShift(str, part2));

    List<Integer> res = new ArrayList<>();
    for (int i : createShift(str, part1)) {
      if (!shiftsSet.subSet(i - num, true, i + num + 1, false).isEmpty()) {
        res.add(i);
      }
    }

    return res;
  }

  private List<Integer> createShift(String text, String pattern) {
    List<Integer> shiftArr = new ArrayList<>();

    final int textLen = text.length();
    final int patLen = pattern.length();
    for (int i = 0; i <= textLen - patLen; i++) {
      boolean matchFlag = true;
      for (int j = 0; j < patLen; j++) {
        if (pattern.charAt(j) != text.charAt(i + j)) {
          matchFlag = false;
          break;
        }
      }

      if (matchFlag) {
        shiftArr.add(i);
      }
    }

    return shiftArr;
  }

  public static void main(String[] args) {
      Scanner inputScanner = new Scanner(System.in);
      String rawInput = inputScanner.nextLine(); 

      String[] inputParts = rawInput.split(" "); 

      String str = inputParts[0];
      String part1 = inputParts[1];
      String part2 = rawInput.substring(str.length() + part1.length() + 2, rawInput.lastIndexOf(" "));
      int num = Integer.parseInt(inputParts[inputParts.length - 1]);

      DifferentSolution diffSolution = new DifferentSolution();
      List<Integer> indicesArr = diffSolution.generateBeautifulIndices(str, part1, part2, num); 

      System.out.println(indicesArr);
  }
}