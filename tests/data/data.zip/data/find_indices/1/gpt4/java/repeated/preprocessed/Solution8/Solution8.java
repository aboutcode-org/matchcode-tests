import java.util.*;
import java.io.*;
import java.util.stream.*;
class Solution8 {
  public List<Integer> getBeautifulIndices(String str, String firstPattern, String secondPattern, int range) {
    TreeSet<Integer> shiftsPatternB = new TreeSet<>(generate(str, secondPattern));
    List<Integer> indices = new ArrayList<>();
    for (int index : generate(str, firstPattern)) {
      if (!shiftsPatternB.subSet(index - range, index + range + 1).isEmpty()) {
        indices.add(index);
      }
    }
    return indices;
  }
  private List<Integer> generate(String input, String pattern) {
    List<Integer> shiftIndices = new ArrayList<>();
    final int inputLength = input.length();
    final int patternLength = pattern.length();
    for (int i = 0; i <= inputLength - patternLength; i++) {
      boolean isMatch = true;
      for (int j = 0; j < patternLength; j++) {
        if (pattern.charAt(j) != input.charAt(i + j)) {
          isMatch = false;
          break;
        }
      }
      if (isMatch) {
        shiftIndices.add(i);
      }
    }
    return shiftIndices;
  }
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    String userInput = scanner.nextLine();
    String[] inputs = userInput.split(" ");
    String str = inputs[0];
    String firstPattern = inputs[1];
    String secondPattern = userInput.substring(str.length() + firstPattern.length() + 2, userInput.lastIndexOf(" "));
    int range = Integer.parseInt(inputs[inputs.length - 1]);
    Solution8 solutions = new Solution8();
    List<Integer> beautifulIndices = solutions.getBeautifulIndices(str, firstPattern, secondPattern, range);
    System.out.println(beautifulIndices);
  }
}