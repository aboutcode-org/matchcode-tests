import java.util.*;

class BeautifulIndices {
  public List<Integer> findBeautifulIndices(String s, String a, String b, int k) {
    TreeSet<Integer> shiftsOfPatternB = new TreeSet<>(createShifts(s, b));

    ArrayList<Integer> results = new ArrayList<>();
    for (int idx : createShifts(s, a)) {
      if (!shiftsOfPatternB.subSet(idx - k, idx + k + 1).isEmpty()) {
        results.add(idx);
      }
    }

    return results;
  }

  private List<Integer> createShifts(String txt, String pat) {
    ArrayList<Integer> shifts = new ArrayList<>();

    int lenOfTxt = txt.length();
    int lenOfPat = pat.length();
    for (int i = 0; i <= lenOfTxt - lenOfPat; i++) {
      boolean matches = true;
      for (int j = 0; j < lenOfPat; j++) {
        if (pat.charAt(j) != txt.charAt(i + j)) {
          matches = false;
          break;
        }
      }

      if (matches) {
        shifts.add(i);
      }
    }

    return shifts;
  }
  
  public static void main(String[] args) {
      Scanner scan = new Scanner(System.in);
      String userInput = scan.nextLine();

      String[] inputParts = userInput.split(" ");

      String s = inputParts[0];
      String a = inputParts[1];
      String b = userInput.substring(s.length() + a.length() + 2, userInput.lastIndexOf(" "));
      int k = Integer.parseInt(inputParts[inputParts.length - 1]);

      BeautifulIndices inst = new BeautifulIndices();
      List<Integer> beautifulIndicesList = inst.findBeautifulIndices(s, a, b, k);

      System.out.println(beautifulIndicesList);
  }
}
