import java.util.*;
import java.io.*;
import java.util.stream.*;
class Main {
  public static List<Integer> getBeautifulIndices(String str, String pattern1, String pattern2, int range) {
    TreeSet<Integer> patternShifts = new TreeSet<>(detectPatternShift(str, pattern2));
    List<Integer> values = new ArrayList<>();
    for (int index : detectPatternShift(str, pattern1)) {
      if (!patternShifts.subSet(index - range, index + range + 1).isEmpty()) {
        values.add(index);
      }
    }
    return values;
  }
  public static List<Integer> detectPatternShift(String mainString, String pattern) {
    List<Integer> shifts = new ArrayList<>();
    final int mainStringLength = mainString.length();
    final int patternLength = pattern.length();
    for (int i = 0; i <= mainStringLength - patternLength; i++) {
      boolean isMatch = true;
      for (int j = 0; j < patternLength; j++) {
        if (pattern.charAt(j) != mainString.charAt(i + j)) {
          isMatch = false;
          break;
        }
      }
      if (isMatch) {
        shifts.add(i);
      }
    }
    return shifts;
  }
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    String inputString = sc.nextLine(); 
    String[] splittedInput = inputString.split(" ");
    String str = splittedInput[0];
    String pattern1 = splittedInput[1];
    String pattern2 = inputString.substring(str.length() + pattern1.length() + 2, inputString.lastIndexOf(" "));
    int range = Integer.parseInt(splittedInput[splittedInput.length - 1]);
    List<Integer> resultedBeautifulIndices = getBeautifulIndices(str, pattern1, pattern2, range);
    System.out.println(resultedBeautifulIndices);
  }
}