import java.util.*;
import java.io.*;
import java.util.stream.*;
public class Solution13 {
  public List<Integer> getBeautifulIndices(String s, String a, String b, int k) {
    SortedSet<Integer> patternShifts = new TreeSet<Integer>(create(s, b));
    List<Integer> output = new LinkedList<Integer>();
    for (Integer shift : create(s, a)) {
      if(!patternShifts.subSet(shift - k, shift + k + 1).isEmpty()) {
        output.add(shift);
      }
    }
    return output;
  }
  private List<Integer> create(String text, String pattern) {
    List<Integer> localShifts = new LinkedList<>();
    int textLength = text.length();
    int patternLength = pattern.length();
    for (int shift = 0; shift <= textLength - patternLength; shift++) {
      boolean foundMatch = true;
      for (int patternIndex = 0; patternIndex < patternLength; patternIndex++) {
        if (text.charAt(shift + patternIndex) != pattern.charAt(patternIndex)) {
          foundMatch = false;
          break;
        }
      }
      if (foundMatch) {
        localShifts.add(shift);
      }
    }
    return localShifts;
  }
  public static void main(String[] args) {
      Scanner inputScanner = new Scanner(System.in);
      String inputLine = inputScanner.nextLine();
      String[] inputs = inputLine.split("\\s");
      String s = inputs[0];
      String a = inputs[1];
      String b = inputLine.substring(s.length() + a.length() + 2, inputLine.lastIndexOf(" "));
      int k = Integer.parseInt(inputs[inputs.length - 1]);
      Solution13 beautifulIndicesFinder = new Solution13();
      List<Integer> beautifulIndices = beautifulIndicesFinder.getBeautifulIndices(s, a, b, k);
      System.out.println(beautifulIndices);
  }
}