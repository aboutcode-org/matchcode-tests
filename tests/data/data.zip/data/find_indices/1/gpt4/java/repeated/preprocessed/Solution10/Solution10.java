import java.util.*;
import java.io.*;
import java.util.stream.*;
public class Solution10 {
  public ArrayList<Integer> findBeautifulIndices(String inputString, String pattern1, String pattern2, int k) {
    TreeSet<Integer> patternShifts = new TreeSet<>(createShifts(inputString, pattern2));
    ArrayList<Integer> finalResult = new ArrayList<>();
    for (int index : createShifts(inputString, pattern1)) {
      if (!patternShifts.subSet(index - k, true, index + k + 1, false).isEmpty()) {
        finalResult.add(index);
      }
    }
    return finalResult;
  }
  private ArrayList<Integer> createShifts(String str, String pattern) {
    ArrayList<Integer> shiftIndices = new ArrayList<>();
    final int lengthOfStr = str.length();
    final int lengthOfPattern = pattern.length();
    for (int idx = 0; idx <= lengthOfStr - lengthOfPattern; idx++) {
      boolean patternMatch = true;
      for (int innerIdx = 0; innerIdx < lengthOfPattern; innerIdx++) {
        if (pattern.charAt(innerIdx) != str.charAt(idx + innerIdx)) {
          patternMatch = false;
          break;
        }
      }
      if (patternMatch) {
        shiftIndices.add(idx);
      }
    }
    return shiftIndices;
  }
    public static void main(String[] args) {
      Scanner scanInput = new Scanner(System.in);
      String inputLine = scanInput.nextLine(); // Reading the entire input line
      // Splitting the input string by spaces
      String[] stringParts = inputLine.split(" ");
      // Extracting s, a, b, and k from the input line parts
      // s is the first part, a is the second, b is the third, k is the last integer
      String s = stringParts[0];
      String a = stringParts[1];
      String b = inputLine.substring(s.length() + a.length() + 2, inputLine.lastIndexOf(" "));
      int k = Integer.parseInt(stringParts[stringParts.length - 1]);
      // Creating an instance of Solution10 and calling the findBeautifulIndices method
      Solution10 indicesInstance = new Solution10();
      ArrayList<Integer> beautifulIndices = indicesInstance.findBeautifulIndices(s, a, b, k);
      // Printing the beautiful indices array
      System.out.println(beautifulIndices);
  }
}