import java.util.*;
import java.io.*;
import java.util.stream.*;
public class Solution2 {
  public List<Integer> getBeautifulIndices(String s, String a, String b, int k) {
    TreeSet<Integer> set = new TreeSet<>(createPatternIndices(s, b));
    ArrayList<Integer> beautifulIndices = new ArrayList<>();
    for (int index : createPatternIndices(s, a)) {
      if (!set.subSet(index - k, index + k + 1).isEmpty()) {
        beautifulIndices.add(index);
      }
    }
    return beautifulIndices;
  }
  private List<Integer> createPatternIndices(String text, String pattern) {
    ArrayList<Integer> indices = new ArrayList<>();
    int m = text.length();
    int n = pattern.length();
    for (int i = 0; i <= m - n; i++) {
      boolean isMatch = true;
      for (int j = 0; j < n; j++) {
        if (pattern.charAt(j) != text.charAt(i + j)) {
          isMatch = false;
          break;
        }
      }
      if (isMatch) {
        indices.add(i);
      }
    }
    return indices;
  }
  public static void main(String[] args) {
    Scanner inputScanner = new Scanner(System.in);
    String userInput = inputScanner.nextLine();
    String[] separatedInput = userInput.split(" ");
    String s = separatedInput[0];
    String a = separatedInput[1];
    String b = userInput.substring(s.length() + a.length() + 2, userInput.lastIndexOf(" "));
    int k = Integer.parseInt(separatedInput[separatedInput.length - 1]);
    Solution2 resultInstance = new Solution2();
    List<Integer> outputIndices = resultInstance.getBeautifulIndices(s, a, b, k);
    System.out.println(outputIndices);
  }
}