import java.util.*;
import java.io.*;
import java.util.stream.*;
public class Solution6 {
  public List<Integer> computeBeautifulIndices(String firstStr, String secondStr, String thirdStr, int digit) {
    TreeSet<Integer> shifts = new TreeSet<>(calculateShifts(firstStr, thirdStr));
    List<Integer> outputList = new LinkedList<>();
    for (int singleIndex : calculateShifts(firstStr, secondStr)) { 
      if (!shifts.subSet(singleIndex - digit, singleIndex + digit + 1).isEmpty()) {
        outputList.add(singleIndex);
      }
    }
    return outputList;
  }
  private List<Integer> calculateShifts(String inText, String patternStr) {
    List<Integer> shiftList = new LinkedList<>();
    final int lengthOfText = inText.length();
    final int lengthOfPattern = patternStr.length();
    for (int i = 0; i <= lengthOfText - lengthOfPattern; i++) {
      boolean isMatched = true;
      for (int j = 0; j < lengthOfPattern; j++) {
        if (patternStr.charAt(j) != inText.charAt(i + j)) {
          isMatched = false;
          break;
        }
      }
      if (isMatched) {
        shiftList.add(i);
      }
    }
    return shiftList;
  }
    public static void main(String[] args) {
      Scanner inputScanner = new Scanner(System.in);
      String inputStr = inputScanner.nextLine();
      String[] parts = inputStr.split(" ");
      String firstString = parts[0];
      String secondString = parts[1];
      String thirdString = inputStr.substring(firstString.length() + secondString.length() + 2, inputStr.lastIndexOf(" "));
      int digit = Integer.parseInt(parts[parts.length - 1]);
      Solution6 clone = new Solution6();
      List<Integer> beautifulIndices = clone.computeBeautifulIndices(firstString, secondString, thirdString, digit);
      System.out.println(beautifulIndices);
  }
}