import java.util.*;
import java.io.*;
import java.util.stream.*;
public class Main {
  public List<Integer> getBeautifulIndices(String str, String firstPattern, String secondPattern, int kRange) {
    SortedSet<Integer> patternShifts = new TreeSet<>(identifyPatterns(str, secondPattern));
    List<Integer> output = new ArrayList<>();
    for (int index : identifyPatterns(str, firstPattern)) {
      if (!patternShifts.subSet(index - kRange, index + kRange + 1).isEmpty()) {
        output.add(index);
      }
    }
    return output;
  }
  private List<Integer> identifyPatterns(String text, String pattern) {
    List<Integer> patternLocations = new ArrayList<>();
    final int txtLength = text.length();
    final int patLength = pattern.length();
    for (int i = 0; i <= txtLength - patLength; i++) {
      boolean isMatch = true;
      for (int j = 0; j < patLength; j++) {
        if (pattern.charAt(j) != text.charAt(i + j)) {
          isMatch = false;
          break;
        }
      }
      if (isMatch) {
        patternLocations.add(i);
      }
    }
    return patternLocations;
  }
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    String userInput = scanner.nextLine();
    String[] divisions = userInput.split(" ");
    String str = divisions[0];
    String firstPattern = divisions[1];
    String secondPattern = userInput.substring(str.length() + firstPattern.length() + 2, userInput.lastIndexOf(" "));
    int kRange = Integer.parseInt(divisions[divisions.length - 1]);
    Main mainInstance = new Main();
    List<Integer> getBeautifulIndices = mainInstance.getBeautifulIndices(str, firstPattern, secondPattern, kRange);
    System.out.println(getBeautifulIndices);
  }
}