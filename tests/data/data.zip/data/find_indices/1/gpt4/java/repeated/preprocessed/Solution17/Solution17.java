import java.util.*;
import java.io.*;
import java.util.stream.*;
public class Solution17 {
  public List<Integer> getBeautifulIndices(String s, String a, String b, int k) {
    // pattern b shift
    TreeSet<Integer> patternShifts = new TreeSet<>(constructList(s, b));
    List<Integer> beautifulIndices = new ArrayList<>();
    for (int index : constructList(s, a)) {
      // check existence of j among [index - k, index + k + 1)
      if (!patternShifts.subSet(index - k, index + k + 1).isEmpty()) {
        beautifulIndices.add(index);
      }
    }
    return beautifulIndices;
  }
  private List<Integer> constructList(String mainString, String pattern) {
    List<Integer> patternShifts = new ArrayList<>();
    final int m = mainString.length();
    final int n = pattern.length();
    for (int idx = 0; idx <= m - n; idx++) {
      boolean isMatch = true;
      for (int j = 0; j < n; j++) {
        if (pattern.charAt(j) != mainString.charAt(idx + j)) {
          isMatch = false;
          break;
        }
      }
      if (isMatch) {
        patternShifts.add(idx);
      }
    }
    return patternShifts;
  }
  public static void main(String[] args) {
    Scanner scanInput = new Scanner(System.in);
    String completeInput = scanInput.nextLine(); // Reads the input line
    // Breaking the input string into pieces using spaces
    String[] inputParts = completeInput.split(" ");
    // Retrieving s, a, b, and k from the input parts
    // s is the first part, a is the second, b is the third, and k is the last integer
    String s = inputParts[0];
    String a = inputParts[1];
    String b = completeInput.substring(s.length() + a.length() + 2,
                                       completeInput.lastIndexOf(" "));
    int k = Integer.parseInt(inputParts[inputParts.length - 1]);
    // Create an Solution17 instance and calling the getBeautifulIndices method
    Solution17 indicesSolution = new Solution17();
    List<Integer> beautifulIndices = indicesSolution.getBeautifulIndices(s, a, b, k);
    // Print the beautiful indices array
    System.out.println(beautifulIndices);
  }
}