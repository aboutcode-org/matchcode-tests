import java.util.*;

public class IndicesFinder {
  public List<Integer> findBeautifulIndices(String inputString, String stringA, String stringB, int range) {
    TreeSet<Integer> shifts = new TreeSet<>(buildShifts(inputString, stringB));

    ArrayList<Integer> indices = new ArrayList<>();
    for (int index : buildShifts(inputString, stringA)) {
      if (!shifts.subSet(index - range, index + range + 1).isEmpty()) {
        indices.add(index);
      }
    }

    return indices;
  }

  private List<Integer> buildShifts(String mainStr, String pattStr) {
    ArrayList<Integer> shifts = new ArrayList<>();
    final int mainLength = mainStr.length();
    final int pattLength = pattStr.length();
    for (int i = 0; i <= mainLength - pattLength; i++) {
      boolean matches = true;
      for (int j = 0; j < pattLength; j++) {
        if (pattStr.charAt(j) != mainStr.charAt(i + j)) {
          matches = false;
          break;
        }
      }

      if (matches) {
        shifts.add(i);
      }
    }

    return shifts;
  }

  public static void main(String[] args) {
      Scanner sc = new Scanner(System.in);
      String str = sc.nextLine(); 
      String[] parts = str.split(" ");
      String strS = parts[0];
      String strA = parts[1];
      String strB = str.substring(strS.length() + strA.length() + 2, str.lastIndexOf(" "));
      int rangeK = Integer.parseInt(parts[parts.length - 1]);
      IndicesFinder finder = new IndicesFinder();
      ArrayList<Integer> beautifulIndices = (ArrayList<Integer>) finder.findBeautifulIndices(strS, strA, strB, rangeK);
      System.out.println(beautifulIndices);
  }
}