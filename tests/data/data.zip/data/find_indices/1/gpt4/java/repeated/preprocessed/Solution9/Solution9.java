import java.util.*;
import java.io.*;
import java.util.stream.*;
public class Solution9 {
  public List<Integer> getBeautifulIndices(String s, String a, String b, int k) {
    TreeSet<Integer> patternShifts = new TreeSet<>(generateShifts(s, b));
    ArrayList<Integer> outputArray = new ArrayList<>();
    for (int current : generateShifts(s, a)) {
      if (!patternShifts.subSet(current - k, current + k + 1).isEmpty()) {
        outputArray.add(current);
      }
    }
    return outputArray;
  }
  private List<Integer> generateShifts(String txt, String pattern) {
    List<Integer> shiftsList = new ArrayList<>();
    int m = txt.length();
    int n = pattern.length();
    for (int i = 0; i <= m - n; i++) {
      boolean isMatching = true;
      for (int j = 0; j < n; j++) {
        if (pattern.charAt(j) != txt.charAt(i + j)) {
          isMatching = false;
          break;
        }
      }
      if (isMatching) {
        shiftsList.add(i);
      }
    }
    return shiftsList;
  }
    public static void main(String[] args) {
      Scanner scanner = new Scanner(System.in);
      String userInput = scanner.nextLine();
      String[] strings = userInput.split(" ");
      String s = strings[0];
      String a = strings[1];
      String b = userInput.substring(s.length() + a.length() + 2, userInput.lastIndexOf(" "));
      int k = Integer.parseInt(strings[strings.length - 1]);
      Solution9 indexAnalysis = new Solution9();
      List<Integer> beautifulIndices = indexAnalysis.getBeautifulIndices(s, a, b, k);
      System.out.println(beautifulIndices);
  }
}