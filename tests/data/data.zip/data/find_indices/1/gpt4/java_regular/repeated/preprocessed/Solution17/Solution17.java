import java.util.*;
import java.io.*;
import java.util.stream.*;
public class Solution17 {
  public List<Integer> findIndices(String str, String charOne, String charTwo, int delta) {
    TreeSet<Integer> patternShift = new TreeSet<>(constructShift(str, charTwo));
    List<Integer> output = new ArrayList<>();
    for (int index : constructShift(str, charOne)) {
      if (!patternShift.subSet(index - delta, index + delta + 1).isEmpty()) {
        output.add(index);
      }
    }
    return output;
  }
  private List<Integer> constructShift(String inputText, String patternInput) {
    List<Integer> shifts = new ArrayList<>();
    final int textLength = inputText.length();
    final int patternLength = patternInput.length();
    for (int i = 0; i <= textLength - patternLength; i++) {
      boolean isMatch = true;
      for (int j = 0; j < patternLength; j++) {
        if (patternInput.charAt(j) != inputText.charAt(i + j)) {
          isMatch = false;
          break;
        }
      }
      if (isMatch) {
        shifts.add(i);
      }
    }
    return shifts;
  }
  public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);
    String inputLine = scan.nextLine(); 
    String[] inputParts = inputLine.split(" ");
    String str = inputParts[0];
    String charOne = inputParts[1];
    String charTwo = inputLine.substring(str.length() + charOne.length() + 2, inputLine.lastIndexOf(" "));
    int delta = Integer.parseInt(inputParts[inputParts.length - 1]);
    Solution17 indicesFinder = new Solution17();
    List<Integer> resultIndices = indicesFinder.findIndices(str, charOne, charTwo, delta);
    System.out.println(resultIndices);
  }
}