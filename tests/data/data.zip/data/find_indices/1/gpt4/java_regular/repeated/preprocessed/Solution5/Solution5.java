import java.util.*;
import java.io.*;
import java.util.stream.*;
class Solution5 {
  public List<Integer> getStunningIndices(String str, String x, String y, int num) {
    TreeSet<Integer> patterns = new TreeSet<>(detect(str, y));
    List<Integer> output = new ArrayList<>();
    for (int index : detect(str, x)) {
      if (!patterns.subSet(index - num, index + num + 1).isEmpty()) {
        output.add(index);
      }
    }
    return output;
  }
  private List<Integer> detect(String content, String target) {
    List<Integer> places = new ArrayList<>();
    final int len1 = content.length();
    final int len2 = target.length();
    for (int i = 0; i <= len1 - len2; i++) {
      boolean found = true;
      for (int j = 0; j < len2; j++) {
        if (target.charAt(j) != content.charAt(i + j)) {
          found = false;
          break;
        }
      }
      if (found) {
        places.add(i);
      }
    }
    return places;
  }
  public static void main(String[] args) {
      Scanner read = new Scanner(System.in);
      String data = read.nextLine();
      String[] elements = data.split(" ");
      String str = elements[0];
      String x = elements[1];
      String y = data.substring(str.length() + x.length() + 2, data.lastIndexOf(" "));
      int num = Integer.parseInt(elements[elements.length - 1]);
      Solution5 si = new Solution5();
      List<Integer> Solution5 = si.getStunningIndices(str, x, y, num);
      System.out.println(Solution5);
  }
}