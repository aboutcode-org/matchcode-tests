import java.util.*;
import java.io.*;
import java.util.stream.*;
public class Solution8 {
  public ArrayList<Integer> findBeautifulIndexes(String s, String a, String b, int k) {
    // calculate pattern b's shift
    TreeSet<Integer> shifts = new TreeSet<>(calculate(s, b));
    ArrayList<Integer> response = new ArrayList<>();
    for (int i : calculate(s, a)) {
      // check existence of j in [i - k, i + k + 1)
      if (!shifts.subSet(i - k, i + k + 1).isEmpty()) {
        response.add(i);
      }
    }
    return response;
  }
  private List<Integer> calculate(String str, String pattern) {
    ArrayList<Integer> shiftList = new ArrayList<>();
    final int m = str.length();
    final int n = pattern.length();
    for (int i = 0; i <= m - n; i++) {
      boolean patternMatch = true;
      for (int j = 0; j < n; j++) {
        if (pattern.charAt(j) != str.charAt(i + j)) {
          patternMatch = false;
          break;
        }
      }
      if (patternMatch) {
        shiftList.add(i);
      }
    }
    return shiftList;
  }
  public static void main(String[] args) {
      Scanner scanner = new Scanner(System.in);
      String text = scanner.nextLine(); // Reads the whole input line
      // Splitting the input string by white spaces
      String[] sections = text.split(" ");
      // Extracting s, a, b, and k from the input sections
      // s will be the first part, a the second, and b the third, k is the last integer
      String s = sections[0];
      String a = sections[1];
      String b = text.substring(s.length() + a.length() + 2, text.lastIndexOf(" "));
      int k = Integer.parseInt(sections[sections.length - 1]);
      // Creating an instance of Solution8 and calling the findBeautifulIndexes method
      Solution8 instance = new Solution8();
      ArrayList<Integer> beautifulIndexes = instance.findBeautifulIndexes(s, a, b, k);
      // Outputting the beautiful indices as a list
      System.out.println(beautifulIndexes);
  }
}