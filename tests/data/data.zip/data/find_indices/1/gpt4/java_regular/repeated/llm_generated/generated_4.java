Here is a semantically equivalent Java clone of the code requested. Some method, parameter and variable names have been changed for maintaining semantic equivalence but ensuring syntactic difference:

```java
import java.util.*;

class MySolution {
    public List<Integer> getBeautifulIndices(String input, String firstPattern, String secondPattern, int range) {
        TreeSet<Integer> secondPatternShifts = new TreeSet<>(generateIndices(input, secondPattern));

        ArrayList<Integer> indices = new ArrayList<>();
        for (int index : generateIndices(input, firstPattern)) {
            if (!secondPatternShifts.subSet(index - range, index + range + 1).isEmpty()) {
                indices.add(index);
            }
        }
        return indices;
    }

    private List<Integer> generateIndices(String source, String target) {
        ArrayList<Integer> indices = new ArrayList<>();

        final int sourceLength = source.length();
        final int targetLength = target.length();
        for (int i = 0; i <= sourceLength - targetLength; i++) {
            boolean found = true;
            for (int j = 0; j < targetLength; j++) {
                if (target.charAt(j) != source.charAt(i + j)) {
                    found = false;
                    break;
                }
            }
            if (found) {
                indices.add(i);
            }
        }
        return indices;
    }

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        String userInput = scan.nextLine();

        String[] inputParts = userInput.split(" ");

        String input = inputParts[0];
        String firstPattern = inputParts[1];
        String secondPattern = userInput.substring(input.length() + firstPattern.length() + 2, userInput.lastIndexOf(" "));
        int range = Integer.parseInt(inputParts[inputParts.length - 1]);

        MySolution mySolution = new MySolution();
        List<Integer> result = mySolution.getBeautifulIndices(input, firstPattern, secondPattern, range);

        System.out.println(result);
    }
}
```