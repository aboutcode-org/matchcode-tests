import java.util.*;
import java.io.*;
import java.util.stream.*;
public class Solution13 {
  public List<Integer> findBeautifulIndices(String input, String firstPattern, String secondPattern, int interval) {
    // Shift of pattern b
    TreeSet<Integer> patternShifts = new TreeSet<>(createShiftList(input, secondPattern));
    List<Integer> indices = new ArrayList<>();
    for (int index : createShiftList(input, firstPattern)) {
      // Check existence of j among [index - interval, index + interval + 1)
      if (!patternShifts.subSet(index - interval, index + interval + 1).isEmpty()) {
        indices.add(index);
      }
    }
    return indices;
  }
  private List<Integer> createShiftList(String text, String pattern) {
    List<Integer> shiftList = new ArrayList<>();
    final int textLength = text.length();
    final int patternLength = pattern.length();
    for (int i = 0; i <= textLength - patternLength; i++) {
      boolean isMatching = true;
      for (int j = 0; j < patternLength; j++) {
        if (pattern.charAt(j) != text.charAt(i + j)) {
          isMatching = false;
          break;
        }
      }
      if (isMatching) {
        shiftList.add(i);
      }
    }
    return shiftList;
  }
  public static void main(String[] args) {
      Scanner scanner = new Scanner(System.in);
      String inputData = scanner.nextLine(); 
      String[] components = inputData.split(" ");
      String input = components[0];
      String firstPattern = components[1];
      String secondPattern = inputData.substring(input.length() + firstPattern.length() + 2, inputData.lastIndexOf(" "));
      int interval = Integer.parseInt(components[components.length - 1]);
      Solution13 bif = new Solution13();
      List<Integer> beautifulIndices = bif.findBeautifulIndices(input, firstPattern, secondPattern, interval);
      System.out.println(beautifulIndices);
  }
}