import java.util.*;
import java.io.*;
import java.util.stream.*;
public class Solution12 {
    public List<Integer> findBeautifulNumbers(String mainString, String firstString, String secondString, int range) {
        TreeSet<Integer> shifts = new TreeSet<>(buildShifts(mainString, secondString));
        List<Integer> beautifulNumbers = new LinkedList<>();
        for (int index : buildShifts(mainString, firstString)) {
            if (!shifts.subSet(index - range, index + range + 1).isEmpty()) {
                beautifulNumbers.add(index);
            }
        }
        return beautifulNumbers;
    }
    private List<Integer> buildShifts(String text, String pattern) {
        List<Integer> shiftList = new ArrayList<>();
        final int textSize = text.length();
        final int patternSize = pattern.length();
        for (int i = 0; i <= textSize - patternSize; i++) {
            boolean isMatch = true;
            for (int j = 0; j < patternSize; j++) {
                if (pattern.charAt(j) != text.charAt(i + j)) {
                    isMatch = false;
                    break;
                }
            }
            if (isMatch) {
                shiftList.add(i);
            }
        }
        return shiftList;
    }
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String userInput = scanner.nextLine(); 
        String[] userInputParts = userInput.split(" ");
        String mainString = userInputParts[0];
        String firstString = userInputParts[1];
        String secondString = userInput.substring(mainString.length() + firstString.length() + 2, userInput.lastIndexOf(" "));
        int range = Integer.parseInt(userInputParts[userInputParts.length - 1]);
        Solution12 finder = new Solution12();
        List<Integer> beautifulNumbers = finder.findBeautifulNumbers(mainString, firstString, secondString, range);
        System.out.println(beautifulNumbers);
    }
}