import java.util.*;
import java.io.*;
import java.util.stream.*;
class Main {
  public List<Integer> lovelyIndices(String str, String first, String second, int range) {
    TreeSet<Integer> positions = new TreeSet<>(compile(str, second));
    ArrayList<Integer> output = new ArrayList<>();
    for (int index : compile(str, first)) {
      if (!positions.subSet(index - range, index + range + 1).isEmpty()) {
        output.add(index);
      }
    }
    return output;
  }
  private List<Integer> compile(String txt, String ptrn) {
    ArrayList<Integer> shifts = new ArrayList<>();
    final int txtLength = txt.length();
    final int ptrnLength = ptrn.length();
    for (int i = 0; i <= txtLength - ptrnLength; i++) {
      boolean isMatched = true;
      for (int j = 0; j < ptrnLength; j++) {
        if (ptrn.charAt(j) != txt.charAt(i + j)) {
          isMatched = false;
          break;
        }
      }
      if (isMatched) {
        shifts.add(i);
      }
    }
    return shifts;
  }
    public static void main(String[] args) {
      Scanner reader = new Scanner(System.in);
      String inputData = reader.nextLine();
      String[] elements = inputData.split(" ");
      String str = elements[0];
      String first = elements[1];
      String second = inputData.substring(str.length() + first.length() + 2, inputData.lastIndexOf(" "));
      int range = Integer.parseInt(elements[elements.length - 1]);
      Main main = new Main();
      List<Integer> lovelyIndices = main.lovelyIndices(str, first, second, range);
      System.out.println(lovelyIndices);
  }
}