import java.util.*;
import java.io.*;
import java.util.stream.*;
class Solution10 {
  public List<Integer> findLovelyIndexes(String str, String firstPat, String secPat, int differenceThreshold) {
    TreeSet<Integer> secPatShifts = new TreeSet<>(locate(str, secPat));
    List<Integer> resultIndexes = new ArrayList<>();
    for (int index : locate(str, firstPat)) {
      if (!secPatShifts.subSet(index - differenceThreshold, index + differenceThreshold + 1).isEmpty()) {
        resultIndexes.add(index);
      }
    }
    return resultIndexes;
  }
  private List<Integer> locate(String mainStr, String subStr) {
    List<Integer> shifts = new ArrayList<>();
    final int totalLength = mainStr.length();
    final int subStrLength = subStr.length();
    for (int i = 0; i <= totalLength - subStrLength; i++) {
      boolean flag = true;
      for (int j = 0; j < subStrLength; j++) {
        if (subStr.charAt(j) != mainStr.charAt(i + j)) {
          flag = false;
          break;
        }
      }
      if (flag) {
        shifts.add(i);
      }
    }
    return shifts;
  }
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    // Reads the entire input line
    String input = scanner.nextLine();
    // We Split the input string by spaces
    String[] segments = input.split(" ");
    // Now extracting s, a, b, and k from the input parts
    // s will be the first segment, a as second, and b as third, k is the final integer
    String str = segments[0];
    String firstPat = segments[1];
    String secPat = input.substring(str.length() + firstPat.length() + 2, input.lastIndexOf(" "));
    int differenceThreshold = Integer.parseInt(segments[segments.length - 1]);
    // Creating an instance of Solution10 and calling the findLovelyIndexes method
    Solution10 finder = new Solution10();
    List<Integer> lovelyIndexes = finder.findLovelyIndexes(str, firstPat, secPat, differenceThreshold);
    // Finally outputting the lovely indices as an array
    System.out.println(lovelyIndexes);
  }
}