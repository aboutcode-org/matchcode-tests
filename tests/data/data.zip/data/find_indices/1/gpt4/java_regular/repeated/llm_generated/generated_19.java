import java.util.*;

class FindIndices {
  public List<Integer> findPatternIndices(String s, String a, String b, int k) {
    // shift of pattern b
    TreeSet<Integer> patternShift = new TreeSet<>(compute(s, b));

    List<Integer> output = new ArrayList<>();
    for (int i : compute(s, a)) {
      // check existence of j among [i - k, i + k + 1)
      if (!patternShift.subSet(i - k, i + k + 1).isEmpty()) {
        output.add(i);
      }
    }

    return output;
  }

  private List<Integer> compute(String text, String pattern) {
    List<Integer> patternIndices = new ArrayList<>();

    final int m = text.length();
    final int n = pattern.length();
    for (int i = 0; i <= m - n; i++) {
      boolean isMatch = true;
      for (int j = 0; j < n; j++) {
        if (pattern.charAt(j) != text.charAt(i + j)) {
          isMatch = false;
          break;
        }
      }

      if (isMatch) {
        patternIndices.add(i);
      }
    }

    return patternIndices;
  }
 
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    String userInput = scanner.nextLine(); // Reads the entire input line

    // Splitting the input string by spaces
    String[] splitInput = userInput.split(" ");

    // Extracting s, a, b, and k from the input parts
    String s = splitInput[0];
    String a = splitInput[1];
    String b = userInput.substring(s.length() + a.length() + 2, userInput.lastIndexOf(" "));
    int k = Integer.parseInt(splitInput[splitInput.length - 1]);

    // Creating an instance of FindIndices and calling the findPatternIndices method
    FindIndices instance = new FindIndices();
    List<Integer> patternIndices = instance.findPatternIndices(s, a, b, k);

    // Outputting the pattern indices as an array
    System.out.println(patternIndices);
  }
}