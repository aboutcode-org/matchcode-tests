import java.util.*;
import java.io.*;
import java.util.stream.*;
public class Solution18 {
  public List<Integer> findSuitableIndices(String text, String pattern1, String pattern2, int range) {
    TreeSet<Integer> pattern2Shifts = new TreeSet<>(buildShiftList(text, pattern2));
    List<Integer> result = new ArrayList<>();
    for (int index : buildShiftList(text, pattern1)) {
      if (!pattern2Shifts.subSet(index - range, index + range + 1).isEmpty()) {
        result.add(index);
      }
    }
    return result;
  }
  private List<Integer> buildShiftList(String text, String pattern) {
    List<Integer> divShifts = new ArrayList<>();
    for (int i = 0; i <= text.length() - pattern.length(); i++) {
      if (text.substring(i, i + pattern.length()).equals(pattern)) {
        divShifts.add(i);
      }
    }
    return divShifts;
  }
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    String[] inputParts = scanner.nextLine().split(" ");
    String text = inputParts[0];
    String pattern1 = inputParts[1];
    String pattern2 = inputParts[2];
    int range = Integer.parseInt(inputParts[3]);
    Solution18 pf = new Solution18();
    List<Integer> suitableIndices = pf.findSuitableIndices(text, pattern1, pattern2, range);
    System.out.println(suitableIndices);
  }
}