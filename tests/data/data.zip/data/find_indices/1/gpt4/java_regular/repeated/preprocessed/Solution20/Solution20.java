import java.util.*;
import java.io.*;
import java.util.stream.*;
class Solution20 {
  public List<Integer> findBeautifulIndices(String inputString, String firstSubstring, String secondSubstring, int range) {
    TreeSet<Integer> substringBShifts = new TreeSet<>(identify(inputString, secondSubstring));
    List<Integer> resultingIndices = new ArrayList<>();
    for (int index : identify(inputString, firstSubstring)) {
      if (!substringBShifts.subSet(index - range, index + range + 1).isEmpty()) {
        resultingIndices.add(index);
      }
    }
    return resultingIndices;
  }
  private List<Integer> identify(String actualString, String searchPattern) {
    List<Integer> stringShift = new ArrayList<>();
    final int lengthOfString = actualString.length();
    final int lengthOfPattern = searchPattern.length();
    for (int i = 0; i <= lengthOfString - lengthOfPattern; i++) {
      boolean foundMatch = true;
      for (int j = 0; j < lengthOfPattern; j++) {
        if (searchPattern.charAt(j) != actualString.charAt(i + j)) {
          foundMatch = false;
          break;
        }
      }
      if (foundMatch) {
        stringShift.add(i);
      }
    }
    return stringShift;
  }
  public static void main(String[] args) {
    Scanner inputScanner = new Scanner(System.in);
    String rawInput = inputScanner.nextLine();
    String[] inputParts = rawInput.split(" ");
    String inputString = inputParts[0];
    String firstSubstring = inputParts[1];
    String secondSubstring = rawInput.substring(inputString.length() + firstSubstring.length() + 2, rawInput.lastIndexOf(" "));
    int range = Integer.parseInt(inputParts[inputParts.length - 1]);
    Solution20 bif = new Solution20();
    List<Integer> beautifulIndices = bif.findBeautifulIndices(inputString, firstSubstring, secondSubstring, range);
    System.out.println(beautifulIndices);
  }
}