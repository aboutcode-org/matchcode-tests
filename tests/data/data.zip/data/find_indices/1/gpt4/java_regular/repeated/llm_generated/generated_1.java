import java.util.*;

public class IndexFinder {
  public List<Integer> prettyIndices(String str, String patternA, String patternB, int offset) {
    TreeSet<Integer> displacements = new TreeSet<>(locate(str, patternB));

    List<Integer> output = new ArrayList<>();
    for (int index : locate(str, patternA)) {
      if (!displacements.subSet(index - offset, index + offset + 1).isEmpty()) {
        output.add(index);
      }
    }

    return output;
  }

  private List<Integer> locate(String txt, String pat) {
    List<Integer> displacement = new ArrayList<>();
    int textLength = txt.length();
    int patternLength = pat.length();
    for (int i = 0; i <= textLength - patternLength; i++) {
      boolean found = true;
      for (int j = 0; j < patternLength; j++) {
        if (pat.charAt(j) != txt.charAt(i + j)) {
          found = false;
          break;
        }
      }

      if (found) {
        displacement.add(i);
      }
    }

    return displacement;
  }
    public static void main(String[] args) {
      Scanner scan = new Scanner(System.in);
      String userInput = scan.nextLine();

      String[] splitInput = userInput.split(" ");

      String str = splitInput[0];
      String patternA = splitInput[1];
      String patternB = userInput.substring(str.length() + patternA.length() + 2, userInput.lastIndexOf(" "));
      int offset = Integer.parseInt(splitInput[splitInput.length - 1]);

      IndexFinder idxFinder = new IndexFinder();
      List<Integer> prettyIndices = idxFinder.prettyIndices(str, patternA, patternB, offset);

      System.out.println(prettyIndices);
  }
}