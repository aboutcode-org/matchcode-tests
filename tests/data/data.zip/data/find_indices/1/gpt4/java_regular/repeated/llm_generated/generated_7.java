import java.util.*;

class BeautifulIndices {
  public List<Integer> findIndices(String str, String pattern1, String pattern2, int range) {
    TreeSet<Integer> pattern2Positions = new TreeSet<>(getPatternPositions(str, pattern2));

    List<Integer> finalOutput = new ArrayList<>();
    for (int pos : getPatternPositions(str, pattern1)) {
      if (!pattern2Positions.subSet(pos - range, pos + range + 1).isEmpty()) {
        finalOutput.add(pos);
      }
    }

    return finalOutput;
  }

  private List<Integer> getPatternPositions(String mainString, String subString) {
    List<Integer> positions = new ArrayList<>();
    final int mainStringLength = mainString.length();
    final int subStringLength = subString.length();
    for (int i = 0; i <= mainStringLength - subStringLength; i++) {
      boolean found = true;
      for (int j = 0; j < subStringLength; j++) {
        if (subString.charAt(j) != mainString.charAt(i + j)) {
          found = false;
          break;
        }
      }

      if (found) {
        positions.add(i);
      }
    }

    return positions;
  }

  public static void main(String[] args) {
    Scanner userScanner = new Scanner(System.in);
    String userInputs = userScanner.nextLine();
    String[] inputs = userInputs.split(" ");
    String str = inputs[0];
    String pattern1 = inputs[1];
    String pattern2 = userInputs.substring(str.length() + pattern1.length() + 2, userInputs.lastIndexOf(" "));
    int range = Integer.parseInt(inputs[inputs.length - 1]);

    BeautifulIndices biInstance = new BeautifulIndices();
    List<Integer> finalIndices = biInstance.findIndices(str, pattern1, pattern2, range);

    System.out.println(finalIndices);
  }
}