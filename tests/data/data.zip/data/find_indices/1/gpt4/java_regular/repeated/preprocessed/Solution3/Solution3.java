import java.util.*;
import java.io.*;
import java.util.stream.*;
public class Solution3 {
    public List<Integer> findIndices(String str, String f1, String f2, int threshold) {
        // f2 pattern shift
        TreeSet<Integer> shifts = new TreeSet<>(shiftPattern(str, f2));
        List<Integer> indices = new ArrayList<>();
        for (int i : shiftPattern(str, f1)) {
            // check existence of j in [i - threshold, i + threshold + 1)
            if (!shifts.subSet(i - threshold, i + threshold + 1).isEmpty()) {
                indices.add(i);
            }
        }
        return indices;
    }
    private List<Integer> shiftPattern(String source, String pattern) {
        List<Integer> shiftList = new ArrayList<>();
        final int lenSource = source.length();
        final int lenPattern = pattern.length();
        for (int i = 0; i <= lenSource - lenPattern; i++) {
            boolean isMatched = true;
            for (int j = 0; j < lenPattern; j++) {
                if (pattern.charAt(j) != source.charAt(i + j)) {
                    isMatched = false;
                    break;
                }
            }
            if (isMatched) {
                shiftList.add(i);
            }
        }
        return shiftList;
    }
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String userInput = scanner.nextLine(); // Reads the entire input line
        // Splitting the input string by spaces
        String[] parts = userInput.split(" ");
        // Extracting str, f1, f2, and threshold from the input parts
        // str will be the first part, f1 the second, and f2 the third, threshold is the last integer
        String str = parts[0];
        String f1 = parts[1];
        String f2 = userInput.substring(str.length() + f1.length() + 2, userInput.lastIndexOf(" "));
        int threshold = Integer.parseInt(parts[parts.length - 1]);
        // Creating an instance of Solution3 and calling the findIndices method
        Solution3 indicesFinder = new Solution3();
        List<Integer> foundIndices = indicesFinder.findIndices(str, f1, f2, threshold);
        // Outputting the found indices as an array
        System.out.println(foundIndices);
    }
}