import java.util.*;
import java.io.*;
import java.util.stream.*;
class Solution15 {
  public List<Integer> getBeautifulIndices(String str, String pattern1, String pattern2, int range) {
    // pattern2 shift
    TreeSet<Integer> shifts = new TreeSet<>(generate(str, pattern2));
    List<Integer> beautifulIndices = new ArrayList<>();
    for (int i : generate(str, pattern1)) {
      // check existence of shift within [i - range, i + range + 1)
      if (!shifts.subSet(i - range, i + range + 1).isEmpty()) {
        beautifulIndices.add(i);
      }
    }
    return beautifulIndices;
  }
  private List<Integer> generate(String text, String pattern) {
    List<Integer> shifts = new ArrayList<>();
    final int text_length = text.length();
    final int pattern_length = pattern.length();
    for (int i = 0; i <= text_length - pattern_length; i++) {
      boolean doesMatch = true;
      for (int j = 0; j < pattern_length; j++) {
        if (pattern.charAt(j) != text.charAt(i + j)) {
          doesMatch = false;
          break;
        }
      }
      if (doesMatch) {
        shifts.add(i);
      }
    }
    return shifts;
  }
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    String input = scanner.nextLine();
    // Splitting the input by spaces
    String[] parts = input.split(" ");
    String str = parts[0];
    String pattern1 = parts[1];
    String pattern2 = input.substring(str.length() + pattern1.length() + 2, input.lastIndexOf(" "));
    int range = Integer.parseInt(parts[parts.length - 1]);
    Solution15 program = new Solution15();
    List<Integer> beautifulIndices = program.getBeautifulIndices(str, pattern1, pattern2, range);
    System.out.println(beautifulIndices);
  }
}