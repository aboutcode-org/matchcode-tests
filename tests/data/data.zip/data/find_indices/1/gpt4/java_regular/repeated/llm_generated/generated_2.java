import java.util.*;

class BeautifulIndicesFinder {
  public List<Integer> findBeautifulIndices(String s, String a, String b, int k) {
    // shift of pattern b
    TreeSet<Integer> positions = new TreeSet<>(generatePositions(s, b));

    List<Integer> outcome = new ArrayList<>();
    for (int i : generatePositions(s, a)) {
      // check existence of j among [i - k, i + k + 1)
      if (!positions.subSet(i - k, true, i + k + 1, false).isEmpty()) {
        outcome.add(i);
      }
    }

    return outcome;
  }

  private List<Integer> generatePositions(String text, String pattern) {
    List<Integer> position = new ArrayList<>();

    final int m = text.length();
    final int n = pattern.length();
    for (int i = 0; i <= m - n; i++) {
      boolean match = true;
      for (int j = 0; j < n; j++) {
        if (pattern.charAt(j) != text.charAt(i + j)) {
          match = false;
          break;
        }
      }

      if (match) {
        position.add(i);
      }
    }

    return position;
  }
    
  public static void main(String[] args) {
      Scanner scanner = new Scanner(System.in);
      String userInput = scanner.nextLine(); 

      // Splitting the input string by spaces
      String[] elements = userInput.split(" ");

      // Extracting s, a, b, and k from the input elements
      String s = elements[0];
      String a = elements[1];
      String b = userInput.substring(s.length() + a.length() + 2, userInput.lastIndexOf(" "));
      int k = Integer.parseInt(elements[elements.length - 1]);

      BeautifulIndicesFinder finder = new BeautifulIndicesFinder();
      List<Integer> beautifulIndices = finder.findBeautifulIndices(s, a, b, k);

      // Outputting the beautiful indices as an array
      System.out.println(beautifulIndices);
  }
}