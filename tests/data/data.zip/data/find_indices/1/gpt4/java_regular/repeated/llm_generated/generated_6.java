import java.util.*;

public class CodeClone {
    public List<Integer> prettyIndicies(String mainString, String patternOne, String patternTwo, int diff) {
        // shift of patternTwo
        TreeSet<Integer> shifts = new TreeSet<>(create(mainString, patternTwo));

        List<Integer> output = new ArrayList<>();
        for (int index : create(mainString, patternOne)) {
            // Validate existence of j in the range [index - diff, index + diff + 1)
            if (!shifts.subSet(index - diff, index + diff + 1).isEmpty()) {
                output.add(index);
            }
        }

        return output;
    }

    private List<Integer> create(String text, String pattern) {
        List<Integer> shift = new ArrayList<>();

        final int textSize = text.length();
        final int patternSize = pattern.length();
        for (int i = 0; i <= textSize - patternSize; i++) {
            boolean flag = true;
            for (int j = 0; j < patternSize; j++) {
                if (pattern.charAt(j) != text.charAt(i + j)) {
                    flag = false;
                    break;
                }
            }

            if (flag) {
                shift.add(i);
            }
        }

        return shift;
    }
    
    public static void main(String[] args) {
        Scanner inputReader = new Scanner(System.in);
        String userInput = inputReader.nextLine(); // Read the entire input line

        // Split input string by spaces
        String[] components = userInput.split(" ");

        // Retrieve mainString, patternOne, patternTwo, and diff from the components
        String mainString = components[0];
        String patternOne = components[1];
        String patternTwo = userInput.substring(mainString.length() + patternOne.length() + 2, userInput.lastIndexOf(" "));
        int diff = Integer.parseInt(components[components.length - 1]);

        // Create an instance of CodeClone and call the prettyIndicies method
        CodeClone codeClone = new CodeClone();
        List<Integer> prettyIndicies = codeClone.prettyIndicies(mainString, patternOne, patternTwo, diff);

        // Print the pretty indicies as an array
        System.out.println(prettyIndicies);
    }
}
