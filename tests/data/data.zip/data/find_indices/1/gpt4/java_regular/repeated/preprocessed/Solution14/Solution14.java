import java.util.*;
import java.io.*;
import java.util.stream.*;
public class Solution14{
    public List<Integer> findBeautifulIndices(String text, String pattern1, String pattern2, int range) {
        // pattern shift of pattern2
        TreeSet<Integer> patternShifts = new TreeSet<>(construct(text, pattern2));
        List<Integer> output = new ArrayList<>();
        for (int index : construct(text, pattern1)) {
            // verify existence of element among range [index - range, index + range + 1)
            if (!patternShifts.subSet(index - range, index + range + 1).isEmpty()) {
                output.add(index);
            }
        }
        return output;
    }
    private List<Integer> construct(String mainText, String matchPattern) {
        List<Integer> shiftList = new ArrayList<>();
        final int textSize = mainText.length();
        final int patternSize = matchPattern.length();
        for (int i = 0; i <= textSize - patternSize; i++) {
            boolean isMatch = true;
            for (int j = 0; j < patternSize; j++) {
                if (matchPattern.charAt(j) != mainText.charAt(i + j)) {
                    isMatch = false;
                    break;
                }
            }
            if (isMatch) {
                shiftList.add(i);
            }
        }
        return shiftList;
    }
    public static void main(String[] args) {
        Scanner inputScanner = new Scanner(System.in);
        String userInput = inputScanner.nextLine(); 
        String[] inputSeparates = userInput.split(" ");
        String text = inputSeparates[0];
        String pattern1 = inputSeparates[1];
        String pattern2 = userInput.substring(text.length() + pattern1.length() + 2, userInput.lastIndexOf(" "));
        int range = Integer.parseInt(inputSeparates[inputSeparates.length - 1]);
        Solution14 indexFinder = new Solution14();
        List<Integer> beautifulIndices = indexFinder.findBeautifulIndices(text, pattern1, pattern2, range);
        System.out.println(beautifulIndices);
    }
}