import java.util.*;
import java.io.*;
import java.util.stream.*;
public class Solution11 {
  public List<Integer> getBeautifulIndices(String str, String firstPattern, String secondPattern, int range) {
    // shift of pattern secondPattern
    TreeSet<Integer> shifts = new TreeSet<>(constructList(str, secondPattern));
    List<Integer> output = new ArrayList<>();
    for (int index : constructList(str, firstPattern)) {
      // check existence of j among [index - range, index + range + 1)
      if (!shifts.subSet(index - range, index + range + 1).isEmpty()) {
        output.add(index);
      }
    }
    return output;
  }
  private List<Integer> constructList(String mainString, String subPattern) {
    List<Integer> shiftList = new ArrayList<>();
    final int stringLength = mainString.length();
    final int patternLength = subPattern.length();
    for (int i = 0; i <= stringLength - patternLength; i++) {
      boolean checkMatched = true;
      for (int j = 0; j < patternLength; j++) {
        if (subPattern.charAt(j) != mainString.charAt(i + j)) {
          checkMatched = false;
          break;
        }
      }
      if (checkMatched) {
        shiftList.add(i);
      }
    }
    return shiftList;
  }
  public static void main(String[] args) {
      Scanner inputReader = new Scanner(System.in);
      String inputData = inputReader.nextLine(); // Reads the entire input line
      // Splitting the input string by spaces
      String[] dataArr = inputData.split(" ");
      // Extracting s, a, b, and k from the input parts
      // s will be the first part, a the second, n b the third, k is the last integer
      String str = dataArr[0];
      String firstPattern = dataArr[1];
      String secondPattern = inputData.substring(str.length() + firstPattern.length() + 2, inputData.lastIndexOf(" "));
      int range = Integer.parseInt(dataArr[dataArr.length - 1]);
      // Creating an instance of Solution11 and calling the getBeautifulIndices method
      Solution11 beautifulIndex = new Solution11();
      List<Integer> optimalIndices = beautifulIndex.getBeautifulIndices(str, firstPattern, secondPattern, range);
      // Outputting the beautiful indices as an array
      System.out.println(optimalIndices);
  }
}