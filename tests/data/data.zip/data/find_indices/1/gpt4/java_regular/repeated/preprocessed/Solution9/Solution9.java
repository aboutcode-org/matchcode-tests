import java.util.*;
import java.io.*;
import java.util.stream.*;
class Solution9 {
  public List<Integer> findIndices(String base, String pattern1, String pattern2, int threshold) {
    TreeSet<Integer> pattern2shifts = new TreeSet<>(generateShifts(base, pattern2));
    List<Integer> output = new ArrayList<>();
    for (int index : generateShifts(base, pattern1)) {
      if (!pattern2shifts.subSet(index - threshold, index + threshold + 1).isEmpty()) {
        output.add(index);
      }
    }
    return output;
  }
  private List<Integer> generateShifts(String mainString, String subString) {
    List<Integer> shifts = new ArrayList<>();
    final int mainLength = mainString.length();
    final int subLength = subString.length();
    for (int i = 0; i <= mainLength - subLength; i++) {
      boolean isMatch = true;
      for (int j = 0; j < subLength; j++) {
        if (subString.charAt(j) != mainString.charAt(i + j)) {
          isMatch = false;
          break;
        }
      }
      if (isMatch) {
        shifts.add(i);
      }
    }
    return shifts;
  }
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    String userInput = scanner.nextLine(); 
    String[] userInputParts = userInput.split(" "); 
    String base = userInputParts[0]; 
    String pattern1 = userInputParts[1]; 
    String pattern2 = userInput.substring(base.length() + pattern1.length() + 2, userInput.lastIndexOf(" "));
    int threshold = Integer.parseInt(userInputParts[userInputParts.length - 1]); 
    Solution9 indexFinder = new Solution9();
    List<Integer> indices = indexFinder.findIndices(base, pattern1, pattern2, threshold); 
    System.out.println(indices);
  }
}