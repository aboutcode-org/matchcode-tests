import java.util.*;
import java.io.*;
import java.util.stream.*;
class Solution11 {
    public List<Integer> beautifulIndices(String s, String a, String b, int k) {
        List<Integer> pa = new ArrayList<>();
        List<Integer> pb = new ArrayList<>();
        int n = s.length();
        for (int i = 0; i <= n - a.length(); i++) {
            if (a.length() > s.length()) break;
            String x = "";
            x = s.substring(i, i + a.length());
            if (x.equals(a)) {
                pa.add(i);
            }
        }
        for (int i = 0; i <= n - b.length(); i++) {
            if (b.length() > s.length()) break;
            String x = "";
            x = s.substring(i, i + b.length());
            if (x.equals(b)) {
                pb.add(i);
            }
        }
        List<Integer> ans = new ArrayList<>();
        int i = 0, j = 0;
        while (i < pa.size() && j < pb.size()) {
            if (Math.abs(pa.get(i) - pb.get(j)) <= k) ans.add(pa.get(i++));
            else if (pa.get(i) < pb.get(j)) i++;
            else j++;
        }
        return ans;
    }
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String input = scanner.nextLine();
        int lastSpaceIndex = input.lastIndexOf(' ');
        int secondLastSpaceIndex = input.lastIndexOf(' ', lastSpaceIndex - 1);
        int k;
        try {
            k = Integer.parseInt(input.substring(lastSpaceIndex + 1));
        }
            System.err.println("Invalid argument for k: " + e.getMessage());
            return;
        }
        String b = input.substring(secondLastSpaceIndex + 1, lastSpaceIndex);
        String sAndA = input.substring(0, secondLastSpaceIndex);
        int firstSpaceIndexAfterS = sAndA.lastIndexOf(' ');
        String s = sAndA.substring(0, firstSpaceIndexAfterS);
        String a = sAndA.substring(firstSpaceIndexAfterS + 1);
        Solution11 solution = new Solution11();
        List<Integer> beautifulIndices = solution.beautifulIndices(s, a, b, k);
        System.out.print("[");
        for (int i = 0; i < beautifulIndices.size(); i++) {
            System.out.print(beautifulIndices.get(i));
            if (i != beautifulIndices.size() - 1) {
                System.out.print(", ");
            }
        }
        System.out.println("]");
    }
}
}