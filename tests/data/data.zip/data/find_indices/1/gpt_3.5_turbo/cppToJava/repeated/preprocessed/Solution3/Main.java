import java.util.*;
import java.io.*;
import java.util.stream.*;
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String input = scanner.nextLine();
        // Find the last two spaces to correctly extract s, a, b, and k
        int lastSpaceIndex = input.lastIndexOf(' ');
        int secondLastSpaceIndex = input.lastIndexOf(' ', lastSpaceIndex - 1);
        // Extracting k from the input
        int k;
        try {
            k = Integer.parseInt(input.substring(lastSpaceIndex + 1));
        }
            System.err.println("Invalid argument for k: " + e.getMessage());
            System.exit(-1); // Exit the program
        }
        // Extracting b (without k)
        String b = input.substring(secondLastSpaceIndex + 1, lastSpaceIndex);
        // Removing b and k parts from input to get s and a
        String sAndA = input.substring(0, secondLastSpaceIndex);
        int firstSpaceIndexAfterS = sAndA.lastIndexOf(' ');
        // Extracting s and a
        String s = sAndA.substring(0, firstSpaceIndexAfterS);
        String a = sAndA.substring(firstSpaceIndexAfterS + 1);
        Solution3 solution = new Solution3();
        List<Integer> beautifulIndices = solution.beautifulIndices(s, a, b, k);
        // Print the result as a list
        System.out.print("[");
        for (int i = 0; i < beautifulIndices.size(); i++) {
            System.out.print(beautifulIndices.get(i));
            if (i != beautifulIndices.size() - 1) {
                System.out.print(", ");
            }
        }
        System.out.println("]");
    }
}
}