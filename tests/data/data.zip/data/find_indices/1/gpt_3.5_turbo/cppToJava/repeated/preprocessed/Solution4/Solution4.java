import java.util.*;
import java.io.*;
import java.util.stream.*;
class Solution4 {
    public List<Integer> beautifulIndices(String s, String a, String b, int k) {
        List<Integer> pa = new ArrayList<>();
        List<Integer> pb = new ArrayList<>();
        int n = s.length();
        for (int i = 0; i <= n - a.length(); i++) {
            if (a.length() > s.length()) break;
            String x = "";
            x = s.substring(i, i + a.length());
            if (x.equals(a)) {
                pa.add(i);
            }
        }
        for (int i = 0; i <= n - b.length(); i++) {
            if (b.length() > s.length()) break;
            String x = "";
            x = s.substring(i, i + b.length());
            if (x.equals(b)) {
                pb.add(i);
            }
        }
        List<Integer> ans = new ArrayList<>();
        int i = 0, j = 0;
        while (i < pa.size() && j < pb.size()) {
            if (Math.abs(pa.get(i) - pb.get(j)) <= k) ans.add(pa.get(i));
            i++;
            if (pa.get(i) < pb.get(j)) i++;
            else j++;
        }
        return ans;
    }
}