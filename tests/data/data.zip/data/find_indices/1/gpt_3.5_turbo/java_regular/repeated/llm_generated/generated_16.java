import java.util.*;
import java.util.List;
import java.util.ArrayList;
import java.util.TreeSet;

class Solution {
    public List<Integer> beautifulIndices(String s, String a, String b, int k) {
        TreeSet<Integer> shifts = new TreeSet<>(build(s, b));

        List<Integer> result = new ArrayList<>();
        for (int i : build(s, a)) {
            if (!shifts.subSet(i - k, i + k + 1).isEmpty()) {
                result.add(i);
            }
        }

        return result;
    }

    private List<Integer> build(String text, String pattern) {
        List<Integer> shift = new ArrayList<>();

        final int m = text.length();
        final int n = pattern.length();
        for (int i = 0; i <= m - n; i++) {
            boolean match = true;
            for (int j = 0; j < n; j++) {
                if (pattern.charAt(j) != text.charAt(i + j)) {
                    match = false;
                    break;
                }
            }

            if (match) {
                shift.add(i);
            }
        }

        return shift;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String input = scanner.nextLine();

        String[] parts = input.split(" ");

        String s = parts[0];
        String a = parts[1];
        String b = input.substring(s.length() + a.length() + 2, input.lastIndexOf(" "));
        int k = Integer.parseInt(parts[parts.length - 1]);

        Solution solution = new Solution();
        List<Integer> beautifulIndices = solution.beautifulIndices(s, a, b, k);

        System.out.println(beautifulIndices);
    }
}