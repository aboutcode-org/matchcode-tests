import java.util.*;
import java.io.*;
import java.util.stream.*;
class Solution16 {
    public List<Integer> beautifulIndices(String s, String a, String b, int k) {
        List<Integer> aList = KMP.search(s, a);
        List<Integer> bList = KMP.search(s, b);
        List<Integer> ans = new ArrayList<>();
        while (!aList.isEmpty() && !bList.isEmpty()) {
            while (!bList.isEmpty() && bList.get(0) < aList.get(0) - k) {
                bList.remove(0);
            }
            if (!bList.isEmpty() && Math.abs(aList.get(0) - bList.get(0)) <= k) {
                ans.add(aList.get(0));
            }
            aList.remove(0);
        }
        return ans;
    }
    public static void main(String[] args) {
        // Assuming the input format is "s a b k"
        Scanner scanner = new Scanner(System.in);
        String inputString = scanner.nextLine();
        String[] parts = inputString.split(" ");
        String s = parts[0];
        String a = parts[1];
        String b = parts[2];
        int k = Integer.parseInt(parts[3]);
        Solution16 solution = new Solution16();
        List<Integer> beautifulIndices = solution.beautifulIndices(s, a, b, k);
        System.out.println(beautifulIndices);
    }
}