import java.util.*;
import java.io.*;
import java.util.stream.*;
class Solution {
    public List<Integer> beautifulIndices(String s, String a, String b, int k) {
        List<Integer> indicesA = KMP.search(s, a);
        List<Integer> indicesB = KMP.search(s, b);
        List<Integer> ans = new ArrayList<>();
        while (!indicesA.isEmpty() && !indicesB.isEmpty()) {
            while (!indicesB.isEmpty() && indicesB.get(0) < indicesA.get(0) - k) {
                indicesB.removeFirst();
            }
            if (!indicesB.isEmpty() && Math.abs(indicesA.get(0) - indicesB.get(0)) <= k) {
                ans.add(indicesA.get(0));
            }
            indicesA.removeFirst();
        }
        return ans;
    }
}