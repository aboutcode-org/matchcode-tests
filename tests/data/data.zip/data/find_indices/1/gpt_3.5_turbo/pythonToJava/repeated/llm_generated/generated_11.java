import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

class KMP {
    public static List<Integer> partial(String pattern) {
        List<Integer> ret = new ArrayList<>();
        ret.add(0);

        for (int i = 1; i < pattern.length(); i++) {
            int j = ret.get(i - 1);
            while (j > 0 && pattern.charAt(j) != pattern.charAt(i)) {
                j = ret.get(j - 1);
            }
            ret.add(j + 1 == pattern.charAt(j) ? j + 1 : j);
        }
        return ret;
    }

    public static List<Integer> search(String T, String P) {
        List<Integer> ret = new ArrayList<>();
        List<Integer> partial = partial(P);
        Deque<Integer> positions = new ArrayDeque<>();
        int j = 0;
        
        for (int i = 0; i < T.length(); i++) {
            while (j > 0 && T.charAt(i) != P.charAt(j)) {
                j = partial.get(j - 1);
            }
            if (T.charAt(i) == P.charAt(j)) {
                j++;
            }
            if (j == P.length()) {
                ret.add(i - (j - 1));
                j = partial.get(j - 1);
            }
        }
        
        return ret;
    }
}

class Solution {
    public List<Integer> beautifulIndices(String s, String a, String b, int k) {
        List<Integer> indicesA = KMP.search(s, a);
        List<Integer> indicesB = KMP.search(s, b);
        List<Integer> ans = new ArrayList<>();

        while (!indicesA.isEmpty() && !indicesB.isEmpty()) {
            while (!indicesB.isEmpty() && indicesB.get(0) < indicesA.get(0) - k) {
                indicesB.removeFirst();
            }

            if (!indicesB.isEmpty() && Math.abs(indicesA.get(0) - indicesB.get(0)) <= k) {
                ans.add(indicesA.get(0));
            }

            indicesA.removeFirst();
        }

        return ans;
    }
}

public class Main {
    public static void main(String[] args) {
        java.util.Scanner scanner = new java.util.Scanner(System.in);
        String inputString = scanner.nextLine();
        String[] parts = inputString.split(" ");
        String s = parts[0];
        String a = parts[1];
        String b = parts[2];
        int k = Integer.parseInt(parts[3]);

        Solution solution = new Solution();
        List<Integer> beautifulIndices = solution.beautifulIndices(s, a, b, k);
        for (int index : beautifulIndices) {
            System.out.print(index + " ");
        }
    }
}