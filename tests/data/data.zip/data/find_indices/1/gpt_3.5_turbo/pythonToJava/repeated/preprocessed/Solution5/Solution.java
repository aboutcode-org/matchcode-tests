import java.util.*;
import java.io.*;
import java.util.stream.*;
class Solution {
    public List<Integer> beautifulIndices(String s, String a, String b, int k) {
        List<Integer> indicesA = KMP.search(s, a);
        List<Integer> indicesB = KMP.search(s, b);
        List<Integer> ans = new ArrayList<>();
        for (int i = 0, j = 0; i < indicesA.size() && j < indicesB.size(); ) {
            while (j < indicesB.size() && indicesB.get(j) < indicesA.get(i) - k) {
                j++;
            }
            if (j < indicesB.size() && Math.abs(indicesA.get(i) - indicesB.get(j)) <= k) {
                ans.add(indicesA.get(i));
            }
            i++;
        }
        return ans;
    }
}