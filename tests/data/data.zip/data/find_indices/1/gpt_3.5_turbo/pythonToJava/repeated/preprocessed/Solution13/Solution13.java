import java.util.*;
import java.io.*;
import java.util.stream.*;
class Solution13 {
    public List<Integer> beautifulIndices(String s, String a, String b, int k) {
        List<Integer> aMatches = KMP.search(s, a);
        List<Integer> bMatches = KMP.search(s, b);
        List<Integer> ans = new LinkedList<>();
        while (!aMatches.isEmpty() && !bMatches.isEmpty()) {
            while (!bMatches.isEmpty() && bMatches.get(0) < aMatches.get(0) - k) {
                bMatches.remove(0);
            }
            if (!bMatches.isEmpty() && Math.abs(aMatches.get(0) - bMatches.get(0)) <= k) {
                ans.add(aMatches.get(0));
            }
            aMatches.remove(0);
        }
        return ans;
    }
    public static void main(String[] args) {
        // Assuming the input format is "s a b k"
        java.util.Scanner scanner = new java.util.Scanner(System.in);
        String inputString = scanner.nextLine();
        String[] parts = inputString.split(" ");
        String s = parts[0];
        String a = parts[1];
        String b = parts[2];
        int k = Integer.parseInt(parts[3]);
        Solution13 solution = new Solution13();
        List<Integer> beautifulIndices = solution.beautifulIndices(s, a, b, k);
        System.out.println(beautifulIndices);
    }
}