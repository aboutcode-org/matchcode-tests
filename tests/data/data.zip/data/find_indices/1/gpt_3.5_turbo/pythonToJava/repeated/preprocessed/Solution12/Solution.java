import java.util.*;
import java.io.*;
import java.util.stream.*;
class Solution {
    public List<Integer> beautifulIndices(String s, String a, String b, int k) {
        List<Integer> aIndices = KMP.search(s, a);
        List<Integer> bIndices = KMP.search(s, b);
        List<Integer> ans = new ArrayList<>();
        while (!aIndices.isEmpty() && !bIndices.isEmpty()) {
            while (!bIndices.isEmpty() && bIndices.get(0) < aIndices.get(0) - k) {
                bIndices.removeFirst();
            }
            if (!bIndices.isEmpty() && Math.abs(aIndices.get(0) - bIndices.get(0)) <= k) {
                ans.add(aIndices.get(0));
            }
            aIndices.remove(0);
        }
        return ans;
    }
}