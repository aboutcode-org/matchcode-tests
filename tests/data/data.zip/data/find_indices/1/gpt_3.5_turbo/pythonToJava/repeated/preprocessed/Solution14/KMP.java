import java.util.*;
import java.io.*;
import java.util.stream.*;
public class KMP {
    public static List<Integer> partial(String pattern) {
        List<Integer> ret = new ArrayList<>();
        ret.add(0);
        for (int i = 1; i < pattern.length(); i++) {
            int j = ret.get(i - 1);
            while (j > 0 && pattern.charAt(j) != pattern.charAt(i)) {
                j = ret.get(j - 1);
            }
            ret.add(j + 1 == pattern.charAt(j) ? j + 1 : j);
        }
        return ret;
    }
    public static List<Integer> search(String T, String P) {
        List<Integer> partial = KMP.partial(P);
        List<Integer> ret = new ArrayList<>();
        int j = 0;
        for (int i = 0; i < T.length(); i++) {
            while (j > 0 && T.charAt(i) != P.charAt(j)) {
                j = partial.get(j - 1);
            }
            if (T.charAt(i) == P.charAt(j)) {
                j++;
            }
            if (j == P.length()) {
                ret.add(i - (j - 1));
                j = partial.get(j - 1);
            }
        }
        return ret;
    }
}