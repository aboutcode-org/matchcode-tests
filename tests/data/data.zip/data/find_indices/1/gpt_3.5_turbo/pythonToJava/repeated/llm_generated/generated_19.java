import java.util.ArrayDeque;
import java.util.Deque;
import java.util.List;
import java.util.ArrayList;

class KMP {
    public static List<Integer> partial(String pattern) {
        List<Integer> ret = new ArrayList<>();
        ret.add(0);

        for (int i = 1; i < pattern.length(); i++) {
            int j = ret.get(i - 1);
            while (j > 0 && pattern.charAt(j) != pattern.charAt(i)) {
                j = ret.get(j - 1);
            }
            ret.add(j + 1 == pattern.charAt(j) ? j + 1 : j);
        }
        return ret;
    }

    public static List<Integer> search(String T, String P) {
        List<Integer> partial = partial(P);
        Deque<Integer> ret = new ArrayDeque<>();
        int j = 0;

        for (int i = 0; i < T.length(); i++) {
            while (j > 0 && T.charAt(i) != P.charAt(j)) {
                j = partial.get(j - 1);
            }
            if (T.charAt(i) == P.charAt(j)) {
                j++;
            }
            if (j == P.length()) {
                ret.add(i - (j - 1));
                j = partial.get(j - 1);
            }
        }

        return new ArrayList<>(ret);
    }
}

class Solution {
    public List<Integer> beautifulIndices(String s, String a, String b, int k) {
        List<Integer> aIndices = KMP.search(s, a);
        List<Integer> bIndices = KMP.search(s, b);
        List<Integer> ans = new ArrayList<>();

        while (!aIndices.isEmpty() && !bIndices.isEmpty()) {
            while (!bIndices.isEmpty() && bIndices.get(0) < aIndices.get(0) - k) {
                bIndices.removeFirst();
            }

            if (!bIndices.isEmpty() && Math.abs(aIndices.get(0) - bIndices.get(0)) <= k) {
                ans.add(aIndices.get(0));
            }

            aIndices.removeFirst();
        }

        return ans;
    }

    public static void main(String[] args) {
        // Assuming the input format is "s a b k"
        Scanner scanner = new Scanner(System.in);
        String inputString = scanner.nextLine();
        String[] parts = inputString.split(" ");
        String s = parts[0];
        String a = parts[1];
        String b = parts[2];
        int k = Integer.parseInt(parts[3]);

        Solution solution = new Solution();
        List<Integer> beautifulIndices = solution.beautifulIndices(s, a, b, k);
        System.out.println(beautifulIndices);
    }
}