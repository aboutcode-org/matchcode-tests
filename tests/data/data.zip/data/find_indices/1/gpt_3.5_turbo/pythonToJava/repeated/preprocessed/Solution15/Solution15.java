import java.util.*;
import java.io.*;
import java.util.stream.*;
class Solution15 {
    public List<Integer> beautifulIndices(String s, String a, String b, int k) {
        List<Integer> aIndices = KMP.search(s, a);
        List<Integer> bIndices = KMP.search(s, b);
        List<Integer> ans = new ArrayList<>();
        while (!aIndices.isEmpty() && !bIndices.isEmpty()) {
            while (!bIndices.isEmpty() && bIndices.get(0) < aIndices.get(0) - k) {
                bIndices.removeFirst();
            }
            if (!bIndices.isEmpty() && Math.abs(aIndices.get(0) - bIndices.get(0)) <= k) {
                ans.add(aIndices.get(0));
            }
            aIndices.removeFirst();
        }
        return ans;
    }
    public static void main(String[] args) {
        // Assuming the input format is "s a b k"
        Scanner scanner = new Scanner(System.in);
        String inputString = scanner.nextLine();
        String[] parts = inputString.split(" ");
        String s = parts[0];
        String a = parts[1];
        String b = parts[2];
        int k = Integer.parseInt(parts[3]);
        Solution15 solution = new Solution15();
        List<Integer> beautifulIndices = solution.beautifulIndices(s, a, b, k);
        System.out.println(beautifulIndices);
    }
}