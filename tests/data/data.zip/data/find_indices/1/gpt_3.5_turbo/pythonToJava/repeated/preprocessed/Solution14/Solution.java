import java.util.*;
import java.io.*;
import java.util.stream.*;
class Solution {
    public List<Integer> beautifulIndices(String s, String a, String b, int k) {
        List<Integer> aResult = KMP.search(s, a);
        List<Integer> bResult = KMP.search(s, b);
        List<Integer> ans = new ArrayList<>();
        int aIndex = 0;
        int bIndex = 0;
        while (!aResult.isEmpty() && !bResult.isEmpty()) {
            while (!bResult.isEmpty() && bResult.get(0) < aResult.get(0) - k) {
                bResult.remove(0);
            }
            if (!bResult.isEmpty() && Math.abs(aResult.get(0) - bResult.get(0)) <= k) {
                ans.add(aResult.get(0));
            }
            aResult.remove(0);
        }
        return ans;
    }
}