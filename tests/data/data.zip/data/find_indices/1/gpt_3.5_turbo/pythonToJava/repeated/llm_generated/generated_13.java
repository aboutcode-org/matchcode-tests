import java.util.Deque;
import java.util.LinkedList;
import java.util.List;

class KMP {
    public static int[] partial(String pattern) {
        // Calculate partial match table: String -> [Int]
        int[] ret = new int[pattern.length() + 1];

        for (int i = 1; i < pattern.length(); i++) {
            int j = ret[i - 1];
            while (j > 0 && pattern.charAt(j) != pattern.charAt(i)) {
                j = ret[j - 1];
            }
            ret[i] = (j + 1) * (pattern.charAt(j) == pattern.charAt(i) ? 1 : 0);
        }
        return ret;
    }

    public static List<Integer> search(String T, String P) {
        // KMP search main algorithm: String -> String -> [Int]
        // Return all the matching position of pattern string P in T
        int[] partial = partial(P);
        Deque<Integer> ret = new LinkedList<>();
        int j = 0;

        for (int i = 0; i < T.length(); i++) {
            while (j > 0 && T.charAt(i) != P.charAt(j)) {
                j = partial[j - 1];
            }
            if (T.charAt(i) == P.charAt(j)) {
                j += 1;
            }
            if (j == P.length()) {
                ret.add(i - (j - 1));
                j = partial[j - 1];
            }
        }
        return new LinkedList<>(ret);
    }
}

class Solution {
    public List<Integer> beautifulIndices(String s, String a, String b, int k) {
        List<Integer> aMatches = KMP.search(s, a);
        List<Integer> bMatches = KMP.search(s, b);
        List<Integer> ans = new LinkedList<>();

        while (!aMatches.isEmpty() && !bMatches.isEmpty()) {
            while (!bMatches.isEmpty() && bMatches.get(0) < aMatches.get(0) - k) {
                bMatches.remove(0);
            }

            if (!bMatches.isEmpty() && Math.abs(aMatches.get(0) - bMatches.get(0)) <= k) {
                ans.add(aMatches.get(0));
            }

            aMatches.remove(0);
        }

        return ans;
    }

    public static void main(String[] args) {
        // Assuming the input format is "s a b k"
        java.util.Scanner scanner = new java.util.Scanner(System.in);
        String inputString = scanner.nextLine();
        String[] parts = inputString.split(" ");
        
        String s = parts[0];
        String a = parts[1];
        String b = parts[2];
        int k = Integer.parseInt(parts[3]);

        Solution solution = new Solution();
        List<Integer> beautifulIndices = solution.beautifulIndices(s, a, b, k);
        System.out.println(beautifulIndices);
    }
}