import java.util.*;
import java.io.*;
import java.util.stream.*;
class Solution11 {
  public List<Integer> findBeautifulIndices(String text, String pattern1, String pattern2, int threshold) {
    TreeSet<Integer> pattern2Shifts = new TreeSet<>(findShifts(text, pattern2));
    List<Integer> result = new ArrayList<>();
    for (int shift : findShifts(text, pattern1)) {
      if (!pattern2Shifts.subSet(shift - threshold, shift + threshold + 1).isEmpty()) {
        result.add(shift);
      }
    }
    return result;
  }
  private List<Integer> findShifts(String text, String pattern) {
    List<Integer> shifts = new ArrayList<>();
    final int n = text.length();
    final int m = pattern.length();
    for (int i = 0; i <= n - m; i++) {
      boolean match = true;
      for (int j = 0; j < m; j++) {
        if (pattern.charAt(j) != text.charAt(i + j)) {
          match = false;
          break;
        }
     }
      if (match) {
        shifts.add(i);
      }
    }
    return shifts;
  }
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    String inputString = scanner.nextLine();
    String[] parts = inputString.split(" ");
    String text = parts[0];
    String pattern1 = parts[1];
    String pattern2 = inputString.substring(text.length() + pattern1.length() + 2, inputString.lastIndexOf(" "));
    int threshold = Integer.parseInt(parts[parts.length - 1]);
    Solution11 alternativeSolution = new Solution11();
    List<Integer> beautifulIndices = alternativeSolution.findBeautifulIndices(text, pattern1, pattern2, threshold);
    System.out.println(beautifulIndices);
  }
}