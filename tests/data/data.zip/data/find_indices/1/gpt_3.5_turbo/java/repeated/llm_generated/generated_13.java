import java.util.*;

class Solution {
  public List<Integer> findIndices(String str, String pattern1, String pattern2, int num) {
    TreeSet<Integer> shifts = new TreeSet<>(search(str, pattern2));

    List<Integer> res = new ArrayList<>();
    for (int i : search(str, pattern1)) {
      if (!shifts.subSet(i - num, i + num + 1).isEmpty()) {
        res.add(i);
      }
    }

    return res;
  }

  private List<Integer> search(String text, String pattern) {
    List<Integer> shift = new ArrayList<>();

    final int len = text.length();
    final int patLen = pattern.length();
    for (int i = 0; i <= len - patLen; i++) {
      boolean match = true;
      for (int j = 0; j < patLen; j++) {
        if (pattern.charAt(j) != text.charAt(i + j)) {
          match = false;
          break;
        }
      }

      if (match) {
        shift.add(i);
      }
    }

    return shift;
  }

  public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);
    String input = scan.nextLine();

    String[] parts = input.split(" ");

    String str = parts[0];
    String pattern1 = parts[1];
    String pattern2 = input.substring(str.length() + pattern1.length() + 2, input.lastIndexOf(" "));
    int num = Integer.parseInt(parts[parts.length - 1]);

    Solution sol = new Solution();
    List<Integer> indices = sol.findIndices(str, pattern1, pattern2, num);

    System.out.println(indices);
  }
}