import java.util.*;
import java.io.*;
import java.util.stream.*;
class Solution9 {
  public List<Integer> findIndices(String inputString, String firstString, String secondString, int num) {
    // shift of secondString
    TreeSet<Integer> shiftings = new TreeSet<>(build(inputString, secondString));
    List<Integer> answers = new ArrayList<>();
    for (int index : build(inputString, firstString)) {
      // check existence of j among [i - num, i + num + 1)
      if (!shiftings.subSet(index - num, index + num + 1).isEmpty()) {
        answers.add(index);
      }
    }
    return answers;
  }
  private List<Integer> build(String text, String pattern) {
    List<Integer> shifts = new ArrayList<>();
    final int textLength = text.length();
    final int patternLength = pattern.length();
    for (int i = 0; i <= textLength - patternLength; i++) {
      boolean matching = true;
      for (int j = 0; j < patternLength; j++) {
        if (pattern.charAt(j) != text.charAt(i + j)) {
          matching = false;
          break;
        }
      }
      if (matching) {
        shifts.add(i);
      }
    }
    return shifts;
  }
    public static void main(String[] arguments) {
      Scanner scanner = new Scanner(System.in);
      String userString = scanner.nextLine(); // Reads the entire user input line
      // Splitting the user input string by spaces
      String[] separatedParts = userString.split(" ");
      // Extracting inputString, firstString, secondString, and num from the separated parts
      // inputString will be the first part, firstString the second, and secondString the third, num is the last integer
      String inputString = separatedParts[0];
      String firstString = separatedParts[1];
      String secondString = userString.substring(inputString.length() + firstString.length() + 2, userString.lastIndexOf(" "));
      int num = Integer.parseInt(separatedParts[separatedParts.length - 1]);
      // Creating an instance of Solution9 and calling the findIndices method
      Solution9 solution = new Solution9();
      List<Integer> result = solution.findIndices(inputString, firstString, secondString, num);
      // Outputting the indices as an array
      System.out.println(result);
  }
}