import java.util.*;

class Solution {
  public List<Integer> findBeautifulIndices(String s, String a, String b, int kValue) {
    TreeSet<Integer> shiftsOfB = new TreeSet<>(calculateShifts(s, b));

    List<Integer> resultIndices = new ArrayList<>();
    for (int index : calculateShifts(s, a)) {
      if (!shiftsOfB.subSet(index - kValue, index + kValue + 1).isEmpty()) {
        resultIndices.add(index);
      }
    }

    return resultIndices;
  }

  private List<Integer> calculateShifts(String textString, String patternString) {
    List<Integer> shiftsList = new ArrayList<>();

    final int textLength = textString.length();
    final int patternLength = patternString.length();
    for (int i = 0; i <= textLength - patternLength; i++) {
      boolean isMatch = true;
      for (int j = 0; j < patternLength; j++) {
        if (patternString.charAt(j) != textString.charAt(i + j)) {
          isMatch = false;
          break;
        }
      }

      if (isMatch) {
        shiftsList.add(i);
      }
    }

    return shiftsList;
  }
    public static void main(String[] args) {
      Scanner scan = new Scanner(System.in);
      String inputString = scan.nextLine(); 

      String[] partsArray = inputString.split(" ");

      String sString = partsArray[0];
      String aString = partsArray[1];
      String bString = inputString.substring(sString.length() + aString.length() + 2, inputString.lastIndexOf(" "));
      int k = Integer.parseInt(partsArray[partsArray.length - 1]);

      Solution sol = new Solution();
      List<Integer> beautifulIndicesList = sol.findBeautifulIndices(sString, aString, bString, k);

      System.out.println(beautifulIndicesList);
  }
}