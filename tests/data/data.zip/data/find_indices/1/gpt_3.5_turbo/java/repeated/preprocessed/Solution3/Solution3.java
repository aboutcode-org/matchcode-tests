import java.util.*;
import java.io.*;
import java.util.stream.*;
class Solution3 {
  public List<Integer> findBeautifulIndices(String str, String pattern1, String pattern2, int num) {
    // create TreeSet of shifts dependent on second pattern
    TreeSet<Integer> shifts = new TreeSet<>(createShifts(str, pattern2));
    List<Integer> beautifulIndices = new ArrayList<>();
    for (int i : createShifts(str, pattern1)) {
      // check if indices exists in [i - num, i + num + 1)
      if (!shifts.subSet(i - num, i + num + 1).isEmpty()) {
        beautifulIndices.add(i);
      }
    }
    return beautifulIndices;
  }
  private List<Integer> createShifts(String text, String pattern) {
    List<Integer> shifts = new ArrayList<>();
    final int textSize = text.length();
    final int patSize = pattern.length();
    for (int i = 0; i <= textSize - patSize; i++) {
      boolean match = true;
      for (int j = 0; j < patSize; j++) {
        if (pattern.charAt(j) != text.charAt(i + j)) {
          match = false;
          break;
        }
      }
      if (match) {
        shifts.add(i);
      }
    }
    return shifts;
  }
    public static void main(String[] args) {
      Scanner scanner = new Scanner(System.in);
      String input = scanner.nextLine(); // Reads the input line
      // Splitting the input string by spaces
      String[] inputParts = input.split(" ");
      // Extract s, a, b, and num from input
      String s = inputParts[0];
      String a = inputParts[1];
      String b = input.substring(s.length() + a.length() + 2, input.lastIndexOf(" "));
      int num = Integer.parseInt(inputParts[inputParts.length - 1]);
      // Create instance of Solution3 and call findBeautifulIndices method
      Solution3 solution = new Solution3();
      List<Integer> beautifulIndices = solution.findBeautifulIndices(s, a, b, num);
      // Output beautiful indices as an array
      System.out.println(beautifulIndices);
  }
}