import java.util.*;
import java.io.*;
import java.util.stream.*;
class Solution16 {
  public List<Integer> specialIndexes(String text, String firstWord, String secondWord, int threshold) {
    TreeSet<Integer> firstWordIndices = new TreeSet<>(search(text, secondWord));
    List<Integer> result = new ArrayList<>();
    for (int i : search(text, firstWord)) {
      if (!firstWordIndices.subSet(i - threshold, i + threshold + 1).isEmpty()) {
        result.add(i);
      }
    }
    return result;
  }
  private List<Integer> search(String input, String keyword) {
    List<Integer> output = new ArrayList<>();
    final int inputLength = input.length();
    final int keywordLength = keyword.length();
    for (int i = 0; i <= inputLength - keywordLength; i++) {
      boolean matchFlag = true;
      for (int j = 0; j < keywordLength; j++) {
        if (keyword.charAt(j) != input.charAt(i + j)) {
          matchFlag = false;
          break;
        }
      }
      if (matchFlag) {
        output.add(i);
      }
    }
    return output;
  }
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    String userInput = scanner.nextLine(); 
    String[] inputParts = userInput.split(" ");
    String text = inputParts[0];
    String firstWord = inputParts[1];
    String secondWord = userInput.substring(text.length() + firstWord.length() + 2, userInput.lastIndexOf(" "));
    int threshold = Integer.parseInt(inputParts[inputParts.length - 1]);
    Solution16 strategy = new Solution16();
    List<Integer> resultIndexes = strategy.specialIndexes(text, firstWord, secondWord, threshold);
    System.out.println(resultIndexes);
  }
}