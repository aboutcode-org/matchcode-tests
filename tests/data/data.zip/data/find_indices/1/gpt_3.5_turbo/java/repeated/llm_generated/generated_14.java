import java.util.*;

class Solution {
  public List<Integer> indices(String s, String a, String b, int k) {
    // shift of pattern a
    TreeSet<Integer> shifts = new TreeSet<>(compute(s, a));

    List<Integer> res = new ArrayList<>();
    for (int i : compute(s, b)) {
      // check existence of j among [i - k, i + k + 1)
      if (!shifts.subSet(i - k, i + k + 1).isEmpty()) {
        res.add(i);
      }
    }

    return res;
  }

  private List<Integer> computeShift(String str, String pat) {
    List<Integer> shift = new ArrayList<>();

    final int m = str.length();
    final int n = pat.length();
    for (int i = 0; i <= m - n; i++) {
      boolean match = true;
      for (int j = 0; j < n; j++) {
        if (pat.charAt(j) != str.charAt(i + j)) {
          match = false;
          break;
        }
      }

      if (match) {
        shift.add(i);
      }
    }

    return shift;
  }
  
  public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);
    String input = scan.nextLine(); // Reads the entire input line

    // Splitting the input string using spaces
    String[] parts = input.split(" ");

    // Extracting s, a, b, and k from the input parts
    String str = parts[0];
    String patternA = parts[1];
    String patternB = input.substring(str.length() + patternA.length() + 2, input.lastIndexOf(" "));
    int num = Integer.parseInt(parts[parts.length - 1]);

    Solution obj = new Solution();
    List<Integer> indices = obj.indices(str, patternA, patternB, num);

    // Output the indices as an array
    System.out.println(indices);
  }
}