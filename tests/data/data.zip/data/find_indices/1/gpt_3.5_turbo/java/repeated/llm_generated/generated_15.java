import java.util.*;

class Solution {
  public List<Integer> findBeautifulIndices(String str, String x, String y, int threshold) {
    TreeSet<Integer> shifts = new TreeSet<>(calculateShifts(str, y));

    List<Integer> result = new ArrayList<>();
    for (int index : calculateShifts(str, x)) {
      if (!shifts.subSet(index - threshold, index + threshold + 1).isEmpty()) {
        result.add(index);
      }
    }

    return result;
  }

  private List<Integer> calculateShifts(String text, String pattern) {
    List<Integer> shift = new ArrayList<>();

    final int textLength = text.length();
    final int patternLength = pattern.length();
    for (int i = 0; i <= textLength - patternLength; i++) {
      boolean match = true;
      for (int j = 0; j < patternLength; j++) {
        if (pattern.charAt(j) != text.charAt(i + j)) {
          match = false;
          break;
        }
      }

      if (match) {
        shift.add(i);
      }
    }

    return shift;
  }

  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    String userInput = scanner.nextLine();

    String[] parts = userInput.split(" ");

    String str = parts[0];
    String x = parts[1];
    String y = userInput.substring(str.length() + x.length() + 2, userInput.lastIndexOf(" "));
    int threshold = Integer.parseInt(parts[parts.length - 1]);

    Solution solution = new Solution();
    List<Integer> beautifulIndices = solution.findBeautifulIndices(str, x, y, threshold);

    System.out.println(beautifulIndices);
  }
}