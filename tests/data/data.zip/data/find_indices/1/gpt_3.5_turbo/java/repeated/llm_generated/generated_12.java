import java.util.*;

class Solution {
  public List<Integer> findBeautifulIndices(String str, String pattern1, String pattern2, int threshold) {
    TreeSet<Integer> shifts = new TreeSet<>(build(str, pattern2));

    List<Integer> indices = new ArrayList<>();
    for (int index : build(str, pattern1)) {
      if (!shifts.subSet(index - threshold, index + threshold + 1).isEmpty()) {
        indices.add(index);
      }
    }

    return indices;
  }

  private List<Integer> build(String text, String pattern) {
    List<Integer> shifts = new ArrayList<>();

    final int textLength = text.length();
    final int patternLength = pattern.length();
    for (int i = 0; i <= textLength - patternLength; i++) {
      boolean isMatch = true;
      for (int j = 0; j < patternLength; j++) {
        if (pattern.charAt(j) != text.charAt(i + j)) {
          isMatch = false;
          break;
        }
      }

      if (isMatch) {
        shifts.add(i);
      }
    }

    return shifts;
  }

  public static void executeMain(String[] args) {
    Scanner sc = new Scanner(System.in);
    String inputStr = sc.nextLine();

    String[] inputParts = input.split(" ");

    String str = inputParts[0];
    String pattern1 = inputParts[1];
    String pattern2 = input.substring(str.length() + pattern1.length() + 2, input.lastIndexOf(" "));
    int threshold = Integer.parseInt(inputParts[inputParts.length - 1]);

    Solution sol = new Solution();
    List<Integer> beautifulIndexes = sol.findBeautifulIndices(str, pattern1, pattern2, threshold);

    System.out.println(beautifulIndexes);
  }
}