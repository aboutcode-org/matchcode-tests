import java.util.*;
import java.io.*;
import java.util.stream.*;
class Solution2 {
  public List<Integer> findIndices(String str, String sub1, String sub2, int limit) {
    TreeSet<Integer> shifts = new TreeSet<>(search(str, sub2));
    List<Integer> results = new ArrayList<>();
    for (int index : search(str, sub1)) {
      if (!shifts.subSet(index - limit, index + limit + 1).isEmpty()) {
        results.add(index);
      }
    }
    return results;
  }
  private List<Integer> search(String text, String pattern) {
    List<Integer> positions = new ArrayList<>();
    final int m = text.length();
    final int n = pattern.length();
    for (int i = 0; i <= m - n; i++) {
      boolean match = true;
      for (int j = 0; j < n; j++) {
        if (pattern.charAt(j) != text.charAt(i + j)) {
          match = false;
          break;
        }
      }
      if (match) {
        positions.add(i);
      }
    }
    return positions;
  }
  public static void main(String[] args) {
    Scanner inputScanner = new Scanner(System.in);
    String inputStr = inputScanner.nextLine();
    String[] parts = inputStr.split(" ");
    String text = parts[0];
    String subStr1 = parts[1];
    String subStr2 = inputStr.substring(text.length() + subStr1.length() + 2, inputStr.lastIndexOf(" "));
    int limit = Integer.parseInt(parts[parts.length - 1]);
    Solution2 sol = new Solution2();
    List<Integer> indices = sol.findIndices(text, subStr1, subStr2, limit);
    System.out.println(indices);
  }
}