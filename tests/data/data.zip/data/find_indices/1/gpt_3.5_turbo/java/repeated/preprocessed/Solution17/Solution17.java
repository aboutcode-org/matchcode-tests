import java.util.*;
import java.io.*;
import java.util.stream.*;
class Solution17 {
  public List<Integer> wonderfulIndices(String s, String a, String b, int k) {
    // shift of pattern b
    TreeSet<Integer> shifts = new TreeSet<>(analyze(s, b));
    List<Integer> output = new ArrayList<>();
    for (int i : analyze(s, a)) {
      // verify existence of j among [i - k, i + k + 1)
      if (!shifts.subSet(i - k, i + k + 1).isEmpty()) {
        output.add(i);
      }
    }
    return output;
  }
  private List<Integer> analyze(String text, String pattern) {
    List<Integer> shift = new ArrayList<>();
    final int m = text.length();
    final int n = pattern.length();
    for (int i = 0; i <= m - n; i++) {
      boolean match = true;
      for (int j = 0; j < n; j++) {
        if (pattern.charAt(j) != text.charAt(i + j)) {
          match = false;
          break;
        }
      }
      if (match) {
        shift.add(i);
      }
    }
    return shift;
  }
    public static void main(String[] arguments) {
      Scanner scanner = new Scanner(System.in);
      String input = scanner.nextLine(); 
      String[] parts = input.split(" ");
      String s = parts[0];
      String a = parts[1];
      String b = input.substring(s.length() + a.length() + 2, input.lastIndexOf(" "));
      int k = Integer.parseInt(parts[parts.length - 1]);
      Solution17 solution = new Solution17();
      List<Integer> wonderfulIndices = solution.wonderfulIndices(s, a, b, k);
      System.out.println(wonderfulIndices);
  }
}