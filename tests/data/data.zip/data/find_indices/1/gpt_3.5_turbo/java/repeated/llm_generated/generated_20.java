import java.util.*;

class Solution {
  public List<Integer> findDistinctIndices(String text, String pattern1, String pattern2, int threshold) {
    TreeSet<Integer> shifts = new TreeSet<>(generateIndices(text, pattern2));

    List<Integer> result = new ArrayList<>();
    for (int index : generateIndices(text, pattern1)) {
      if (!shifts.subSet(index - threshold, index + threshold + 1).isEmpty()) {
        result.add(index);
      }
    }

    return result;
  }

  private List<Integer> generateIndices(String text, String pattern) {
    List<Integer> indices = new ArrayList<>();

    final int m = text.length();
    final int n = pattern.length();
    for (int i = 0; i <= m - n; i++) {
      boolean match = true;
      for (int j = 0; j < n; j++) {
        if (pattern.charAt(j) != text.charAt(i + j)) {
          match = false;
          break;
        }
      }

      if (match) {
        indices.add(i);
      }
    }

    return indices;
  }

  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    String input = scanner.nextLine();

    String[] parts = input.split(" ");

    String text = parts[0];
    String pattern1 = parts[1];
    String pattern2 = input.substring(s.length() + a.length() + 2, input.lastIndexOf(" "));
    int threshold = Integer.parseInt(parts[parts.length - 1]);

    Solution solution = new Solution();
    List<Integer> distinctIndices = solution.findDistinctIndices(text, pattern1, pattern2, threshold);

    System.out.println(distinctIndices);
  }
}