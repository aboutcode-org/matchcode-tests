import java.util.*;

class Solution {
  public List<Integer> findIndices(String str, String pattern1, String pattern2, int threshold) {
    TreeSet<Integer> shifts = new TreeSet<>(createShifts(str, pattern2));

    List<Integer> result = new ArrayList<>();
    for (int idx : createShifts(str, pattern1)) {
      if (!shifts.subSet(idx - threshold, idx + threshold + 1).isEmpty()) {
        result.add(idx);
      }
    }

    return result;
  }

  private List<Integer> createShifts(String text, String pattern) {
    List<Integer> shifts = new ArrayList<>();

    final int textLength = text.length();
    final int patternLength = pattern.length();
    for (int i = 0; i <= textLength - patternLength; i++) {
      boolean matched = true;
      for (int j = 0; j < patternLength; j++) {
        if (pattern.charAt(j) != text.charAt(i + j)) {
          matched = false;
          break;
        }
      }

      if (matched) {
        shifts.add(i);
      }
    }

    return shifts;
  }
  
    public static void main(String[] args) {
      Scanner scanner = new Scanner(System.in);
      String input = scanner.nextLine(); 

      String[] parts = input.split(" ");

      String str = parts[0];
      String pattern1 = parts[1];
      String pattern2 = input.substring(str.length() + pattern1.length() + 2, input.lastIndexOf(" "));
      int threshold = Integer.parseInt(parts[parts.length - 1]);

      Solution solution = new Solution();
      List<Integer> indices = solution.findIndices(str, pattern1, pattern2, threshold);

      System.out.println(indices);
  }
}