import java.util.*;

class Solution {
  public List<Integer> perfectIndices(String s, String a, String b, int k) {
    TreeSet<Integer> shifts = new TreeSet<>(calculation(s, b));

    List<Integer> output = new ArrayList<>();
    for (int index : calculation(s, a)) {
      if (!shifts.subSet(index - k, index + k + 1).isEmpty()) {
        output.add(index);
      }
    }

    return output;
  }

  private List<Integer> calculation(String text, String pattern) {
    List<Integer> shift = new ArrayList<>();

    final int lengthText = text.length();
    final int lengthPattern = pattern.length();
    for (int i = 0; i <= lengthText - lengthPattern; i++) {
      boolean matched = true;
      for (int j = 0; j < lengthPattern; j++) {
        if (pattern.charAt(j) != text.charAt(i + j)) {
          matched = false;
          break;
        }
      }

      if (matched) {
        shift.add(i);
      }
    }

    return shift;
  }
    public static void main(String[] arguments) {
      Scanner scanner = new Scanner(System.in);
      String input = scanner.nextLine(); 

      String[] parts = input.split(" ");

      String s = parts[0];
      String a = parts[1];
      String b = input.substring(s.length() + a.length() + 2, input.lastIndexOf(" "));
      int k = Integer.parseInt(parts[parts.length - 1]);

      Solution solution = new Solution();
      List<Integer> perfectIndices = solution.perfectIndices(s, a, b, k);

      System.out.println(perfectIndices);
  }
}