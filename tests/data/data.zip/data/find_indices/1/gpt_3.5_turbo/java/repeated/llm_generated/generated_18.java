import java.util.*;

class Solution {
  public List<Integer> findSpecificIndices(String inputString, String subString1, String subString2, int threshold) {
    TreeSet<Integer> shifts = new TreeSet<>(calculateShifts(inputString, subString2));

    List<Integer> result = new ArrayList<>();
    for (int i : calculateShifts(inputString, subString1)) {
      if (!shifts.subSet(i - threshold, i + threshold + 1).isEmpty()) {
        result.add(i);
      }
    }

    return result;
  }

  private List<Integer> calculateShifts(String mainString, String subString) {
    List<Integer> shiftList = new ArrayList<>();

    final int mainStringLength = mainString.length();
    final int subStringLength = subString.length();
    for (int i = 0; i <= mainStringLength - subStringLength; i++) {
      boolean isMatch = true;
      for (int j = 0; j < subStringLength; j++) {
        if (subString.charAt(j) != mainString.charAt(i + j)) {
          isMatch = false;
          break;
        }
      }

      if (isMatch) {
        shiftList.add(i);
      }
    }

    return shiftList;
  }

    public static void main(String[] inputArgs) {
      Scanner scan = new Scanner(System.in);
      String userInput = scan.nextLine();

      String[] parts = userInput.split(" ");

      String mainString = parts[0];
      String subString1 = parts[1];
      String subString2 = userInput.substring(mainString.length() + subString1.length() + 2, userInput.lastIndexOf(" "));
      int threshold = Integer.parseInt(parts[parts.length - 1]);

      Solution solutionInst = new Solution();
      List<Integer> specificIndices = solutionInst.findSpecificIndices(mainString, subString1, subString2, threshold);

      System.out.println(specificIndices);
  }
}