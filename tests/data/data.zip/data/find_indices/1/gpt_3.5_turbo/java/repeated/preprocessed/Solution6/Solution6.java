import java.util.*;
import java.io.*;
import java.util.stream.*;
class Solution6 {
  public List<Integer> findIndices(String s, String a, String b, int k_value) {
    TreeSet<Integer> shift = new TreeSet<>(process(s, b));
    List<Integer> output = new ArrayList<>();
    for (int index : process(s, a)) {
      if (!shift.subSet(index - k_value, index + k_value + 1).isEmpty()) {
        output.add(index);
      }
    }
    return output;
  }
  private List<Integer> process(String text, String pattern) {
    List<Integer> matches = new ArrayList<>();
    final int length_text = text.length();
    final int length_pattern = pattern.length();
    for (int i = 0; i <= length_text - length_pattern; i++) {
      boolean isMatch = true;
      for (int j = 0; j < length_pattern; j++) {
        if (pattern.charAt(j) != text.charAt(i + j)) {
          isMatch = false;
          break;
        }
      }
      if (isMatch) {
        matches.add(i);
      }
    }
    return matches;
  }
  public static void main(String[] arguments) {
    Scanner inputScanner = new Scanner(System.in);
    String inputData = inputScanner.nextLine();
    String[] dataParts = inputData.split(" ");
    String firstPart = dataParts[0];
    String secondPart = dataParts[1];
    String thirdPart = inputData.substring(firstPart.length() + secondPart.length() + 2, inputData.lastIndexOf(" "));
    int kValue = Integer.parseInt(dataParts[dataParts.length - 1]);
    Solution6 sol = new Solution6();
    List<Integer> indices = sol.findIndices(firstPart, secondPart, thirdPart, kValue);
    System.out.println(indices);
  }
}