import java.util.*;

class Solution {
  public List<Integer> uniqueIndices(String s, String patternA, String patternB, int threshold) {
    TreeSet<Integer> shifts = new TreeSet<>(generate(s, patternB));

    List<Integer> result = new ArrayList<>();
    for (int i : generate(s, patternA)) {
      if (!shifts.subSet(i - threshold, i + threshold + 1).isEmpty()) {
        result.add(i);
      }
    }

    return result;
  }

  private List<Integer> generate(String text, String pattern) {
    List<Integer> shift = new ArrayList<>();

    final int m = text.length();
    final int n = pattern.length();
    for (int i = 0; i <= m - n; i++) {
      boolean matching = true;
      for (int j = 0; j < n; j++) {
        if (pattern.charAt(j) != text.charAt(i + j)) {
          matching = false;
          break;
        }
      }

      if (matching) {
        shift.add(i);
      }
    }

    return shift;
  }

  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    String input = scanner.nextLine();
    String[] parts = input.split(" ");

    String s = parts[0];
    String patternA = parts[1];
    String patternB = input.substring(s.length() + patternA.length() + 2, input.lastIndexOf(" "));
    int threshold = Integer.parseInt(parts[parts.length - 1]);

    Solution solution = new Solution();
    List<Integer> uniqueIndices = solution.uniqueIndices(s, patternA, patternB, threshold);

    System.out.println(uniqueIndices);
  }
}